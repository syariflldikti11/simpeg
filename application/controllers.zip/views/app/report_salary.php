<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=report salary.xls");
?>
<?php 

function rupiah($angka){
  
  $hasil_rupiah = "" . number_format($angka,0,',','.');
  return $hasil_rupiah;

}
?>

<?php
function formatTanggal($date){
    // ubah string menjadi format tanggal
    return date('d-m-Y', strtotime($date));
   }
   
$dari=$_POST['dari'];
$id_beautycian=$_POST['id_beautycian'];
$sampai=$_POST['sampai'];
?>
<center><?= formatTanggal($dari); ?> s/d <?= formatTanggal($sampai); ?></center>
<br />


<table border="0">
<?php
$bc=$this->db->query("Select * from beautycian where id_beautycian='$id_beautycian'");
                        foreach ($bc->result() as $y) :?>
<tr>
<td>Beautycian Name</td>
<td>:<?= $y->name; ?></td>
</tr>
<tr>
<td>Base Salary</td>
<td>:<?= $bs=$y->base_salary; ?></td>
</tr>
<?php endforeach; ?>
</table>

<table border="1">
    <tr>
                          <th>No</th>
                          <th>Transaction No</th>
                      
                          <th>Work Date</th>
                          <th>Service</th>
                          <th>Main Therapist</th>
                          <th>Commission</th>
                    
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                      $no=1;
                      $tm=0;
                     $query=$this->db->query("Select * from main_commission a join beautycian b 
                     on a.id_beautycian=b.id_beautycian join detail_transaction c on a.id_detail_transaction=c.id_detail_transaction where 
                     c.work_date between '$dari' and '$sampai' and b.id_beautycian='$id_beautycian'");
                        foreach ($query->result() as $d) :?>
                                                      
                                                  
                        <tr>
                          <td><?= $no++; ?></td>
                          <td><?= $d->transaction_no; ?></td>
                          <td><?= $d->work_date; ?></td>
                          <td><?= $d->item_service; ?></td>
                         
                          <td><?= $mc=$d->main_commission; ?></td>
                         <?php $tm=$tm+$mc; ?>
                  </tr>
                  <?php endforeach; ?>
                  <tr>
                    <td colspan="5">Total Main Commission</td>
                    <td ><?= $tm; ?></td>
                  </tr>
                  </table>
<p />
                  <table border="1">
    <tr>
                          <th>No</th>
                          <th>Transaction No</th>
                      
                          <th>Work Date</th>
                          <th>Service</th>
                          <th>Asist Therapist</th>
                          <th>Commission</th>
                    
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                      $noo=1;
                      $tc=0;
                     $as=$this->db->query("Select * from assist_commission a join beautycian b 
                     on a.id_beautycian=b.id_beautycian join detail_transaction c on a.id_detail_transaction=c.id_detail_transaction where 
                     c.work_date between '$dari' and '$sampai' and b.id_beautycian='$id_beautycian'");
                        foreach ($as->result() as $c) :?>
                                                      
                        <tr>
                          <td><?= $noo++; ?></td>
                          <td><?= $c->transaction_no; ?></td>
                          <td><?= $c->work_date; ?></td>
                          <td><?= $c->item_service; ?></td>
                          
                          <td><?= $ac=$c->assist_commission; ?></td>
                        
                  </tr>
                  <?php $tc=$tc+$ac; ?>
                  <?php endforeach; ?>
                  <tr>
                    <td colspan="5">Total Assist Commission</td>
                    <td><?= $tc; ?></td>
                  </tr>
                  </table>
                 <br />
                 <?php $thp=0; ?>
                 <table border="1">
                  <tr>
<td>Take Home Pay :</td>
 <td><?= $thp=$bs+$tm+$tc; ?></td>
                        </tr>
                        </table>
 <?php
 exit ()
 ?>