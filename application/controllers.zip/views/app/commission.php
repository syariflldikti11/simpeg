<?php 

function rupiah($angka){
  
  $hasil_rupiah = "" . number_format($angka,0,',','.');
  return $hasil_rupiah;

}
?>
<?php
function tgl($date){
  // ubah string menjadi format tanggal
  return date('d-m-Y', strtotime($date));
 }
 ?>
   <div class="page-breadcrumb">
          <div class="row">
            <div class="col-md-5 align-self-center">
              <h3 class="page-title">Dashboard</h3>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                     <?= $judul; ?>
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
            <div
              class="
                col-md-7
                justify-content-end
                align-self-center
                d-none d-md-flex
              "
            >
             
            </div>
          </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
<div class="row">
            <div class="col-12">
              <div class="card">
                <div class="border-bottom title-part-padding">
                  <h4 class="card-title mb-0"></h4>
                </div>
                <div class="card-body">
                  
                  <div class="table-responsive">
                    <table
                      id="zero_config"
                      class="table table-striped table-bordered"
                    >
                      <thead>
                        <tr>
                        <th>No</th>
                        <th>Transaction No</th>
                       
                          <th>Work Date</th>
                          <th>Patient</th>
                          <th>Service</th>
                          <th>Main Therapist</th>
                          <th>Asist Therapist</th>
                          <th><div align="center">Action</div></th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $no=1; ?>
                  <?php foreach($dt_schedule as $d): ?>
                        <tr>
                        <td><?= $no++; ?></td>
                        <td><a href="<?php echo base_url('app/detail_transaction/'.$d->transaction_no.'/'.$d->jenis);?>"><?= $d->transaction_no; ?></a></td>
                    
                          <td><?= tgl($d->work_date); ?></td>
                          <td><?= $d->patient_number; ?> | <?= $d->patient_name; ?></td>
                          <td><?= $d->item_service; ?></td>
                         <td>  <?php
                                                        $id=$d->id_detail_transaction;
                                                        $query=$this->db->query("Select * from main_commission a join beautycian b on a.id_beautycian=b.id_beautycian where id_detail_transaction='$id'");
                                                        foreach ($query->result() as $m) :?>
                                                        <?= $m->name; ?>
                                                    <?php endforeach; ?></td>
                          
                            <td> <?php
                                                        
                                                        $assist=$this->db->query("Select * from assist_commission a join beautycian b on a.id_beautycian=b.id_beautycian where id_detail_transaction='$id'");
                                                        foreach ($assist->result() as $n) :?>
                                                          <?= $n->name; ?>
                                                    <?php endforeach; ?>
                                                </td>
                                                <td>
                     <div align="center"><?php  if($this->session->userdata('akses')=='1' ) :?>    <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Commission"  data-bs-toggle="modal"
                        data-bs-target="#record<?= $d->id_detail_transaction; ?>"  class="btn btn-primary btn-xs" ><i class="fa fa-money-bill-alt "></i></a> <?php endif; ?>
                         
                         </div>
                      </td>
                        </tr>


                        <div
                        class="modal fade"
                        id="record<?= $d->id_detail_transaction; ?>"
                        tabindex="-1"
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                              Commission
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/medical_record'); ?>
                  <?php
                                                     
                                                        $medical=$this->db->query("Select id_detail_transaction from detail_transaction where id_detail_transaction='$id'");
                                                        foreach ($medical->result() as $r) :?>
                  

                      <div class="mb-3">
                  <input type="hidden" name="id_detail_transaction" value="<?= $r->id_detail_transaction; ?>">
                  
                      </div>
                      <?php
                                                      
                                                        $query=$this->db->query("Select * from main_commission  where id_detail_transaction='$id'");
                                                        foreach ($query->result() as $m) :?>
                  

                      <div class="mb-3">
                        <label for="disabledTextInput1">Main Commission</label>
                        <input
                          type="text"
                          class="form-control"  value="<?= $m->main_commission; ?>" readonly
                        />
                      </div>
                      <?php endforeach; ?>
                      <?php
                                                        
                                                        $query=$this->db->query("Select * from assist_commission where id_detail_transaction='$id'");
                                                        foreach ($query->result() as $n) :?>
                 <div class="mb-3">
                        <label for="disabledTextInput1">Asist Commission</label>
                        <input
                          type="text"
                          class="form-control"  value="<?= $n->assist_commission; ?>" readonly
                        />
                      </div>
                      <?php endforeach; ?>
                      <?php endforeach; ?>
                                         
                    
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>


                     
                      <?php endforeach; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>





         