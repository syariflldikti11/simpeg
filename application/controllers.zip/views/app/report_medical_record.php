<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<script>
  window.print();
</script>
<style type="text/css">
 body{
  -webkit-print-color-adjust:exact;
}
</style>

<div style='mso-element:para-border-div;border:none;border-top:solid windowtext 3.0pt;
padding:1.0pt 0cm 0cm 0cm'>
<table width="100%" border="0">
  <tr>
  
    <td ><p align="center"><b><font size="+2">Klinik Kecantikan Amanda Estetika</font></b><br>
   
        <font size="-2">Jl. Kolonel Sugiono No. 52, Pekapuran Laut, Kec. Banjarmasin Tengah <br />
        Kota Banjarmasin, Kalimantan Selatan 70234, Phone : 0811-2579-957</font>     
    </td>
  </tr>
</table>
<div style='mso-element:para-border-div;border:none;border-top:solid windowtext 3.0pt;
padding:1.0pt 0cm 0cm 0cm'>

<center><h3>MEDICAL RECORD</h3></center>
<table width="100%" border="0">
<?php
                                                        $pt=$this->db->query("Select * from patient where id_patient='$id_patient'");
                                                        foreach ($pt->result() as $m) :?>
  <tr>
    <td width="17%">Patient</td>
    <td width="83%">&nbsp; : <?= $m->patient_number; ?> | <?= $m->patient_name; ?></td>
  </tr>
  <tr>
    <td>Tempat/Tanggal Lahir</td>
    <td>&nbsp; : <?= $m->patient_pob; ?></td>
  </tr>
  <tr>
    <td>Telp/HP</td>
    <td>&nbsp; : <?= $m->patient_phone; ?></td>
  </tr>
  <tr>
    <td>Alamat</td>
    <td>&nbsp; : <?= $m->patient_address; ?></td>
  </tr>
  <?php endforeach; ?>
</table>
<br />
 <table class="w3-table-all">
                                   <thead>
                                        <tr class="w3-black" >
                                           <th>No</th>
                                           
                                           <th>Date</th>
                                           <th>Medical Record</th>
                          <th>Service</th>
                          <th>Obat</th>
                          <th>Main Therapist</th>
                          <th>Asist Therapist</th>
                                 
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $no=1;
                                    $total=0; ?>
                  <?php foreach($dt_medical_record as $d): ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo $no++; ?></td>
                                                 
                          <td><?= $date=$d->work_date; ?></td>
                          <td><?= $d->medical_record; ?></td>
                          <td><?= $d->item_service; ?></td>
                          <td><?php
                                                        $id=$d->transaction_no;
                                                        $que=$this->db->query("Select item_service from detail_transaction where work_date='$date' and detail_item=3 
                                                        and transaction_no='$id'");
                                                        foreach ($que->result() as $ob) :?>
                                                        <?= $ob->item_service; ?> 
                                                    <?php endforeach; ?></td>
                         <td>  <?php
                                                        $id=$d->id_detail_transaction;
                                                        $query=$this->db->query("Select * from main_commission a join beautycian b on a.id_beautycian=b.id_beautycian where id_detail_transaction='$id'");
                                                        foreach ($query->result() as $m) :?>
                                                        <?= $m->name; ?> 
                                                    <?php endforeach; ?></td>
                          
                            <td> <?php
                                                        
                                                        $assist=$this->db->query("Select * from assist_commission a join beautycian b on a.id_beautycian=b.id_beautycian where id_detail_transaction='$id'");
                                                        foreach ($assist->result() as $n) :?>
                                                          <?= $n->name; ?>
                                                    <?php endforeach; ?>
                                                </td>
                                          
                                               
                                        
                                      </tr>
                                       
                                             <?php endforeach; ?>
                                             
                                    </tbody>
                                </table>
