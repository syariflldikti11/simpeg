<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=report item transaction.xls");
?>
<?php 

function rupiah($angka){
  
  $hasil_rupiah = "" . number_format($angka,0,',','.');
  return $hasil_rupiah;

}
?>

<?php
function formatTanggal($date){
    // ubah string menjadi format tanggal
    return date('d-m-Y', strtotime($date));
   }
   
$dari=$_POST['dari'];
$sampai=$_POST['sampai'];
?>
<center><?= formatTanggal($dari); ?> s/d <?= formatTanggal($sampai); ?></center>
<br />
<table border="1">
    <tr>
                          <th>No</th>
                          <th>Transaction No</th>
                        <th>Item</th>
                          <th>Price</th>
                          <th>Qty</th>
                          <th>Discount</th>
                          <th>Total</th>
                    
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                      $no=1;
                     $query=$this->db->query("Select * from detail_transaction a join transaction b
                     on a.transaction_no=b.transaction_no 
                     where b.transaction_date between '$dari' and '$sampai'");
                        foreach ($query->result() as $d) :?>
                                                      
                                                  
                        <tr>
                          <td><?= $no++; ?></td>
                          <td><?= $d->transaction_no; ?></td>
                          <td><?= $d->item_service; ?></td>
                          <td><?= rupiah($d->price); ?></td>
                          <td><?= $d->qty; ?></td>
                          <td><?= $d->discount; ?></td>
                          <td><?= rupiah($d->sub_total); ?></td>
                      
                  </tr>
                  <?php endforeach; ?>
                  </table>

                  <?php
        exit ()
        ?>