<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<script>
  window.print();
</script>
<style type="text/css">
 body{
  -webkit-print-color-adjust:exact;
}
#tb{
  font-size: 70%;
  border:0px;
  width: 100%;
}
#customers {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 70%;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #000;
  color: white;
}

</style>

<div style='mso-element:para-border-div;border:none;border-top:solid windowtext 3.0pt;
padding:1.0pt 0cm 0cm 0cm'>
<table id="tb">
  <tr>
    <td ><center><img width="100px" src="<?= base_url(); ?>/assets/images/logofix.png"></center> </td>
  
    <td ><p align="center"><b><font size="+2">Klinik Kecantikan Amanda Estetika</font></b><br>
   
        <font size="-2">Jl. Kolonel Sugiono No. 52, Pekapuran Laut, Kec. Banjarmasin Tengah <br />
        Kota Banjarmasin, Kalimantan Selatan 70234, Phone : 0811-2579-957</font>     
    </td>
  </tr>
</table>
<div style='mso-element:para-border-div;border:none;border-top:solid windowtext 3.0pt;
padding:1.0pt 0cm 0cm 0cm'>


<?php
 $id_payment;
 $query=$this->db->query("Select * from payment a join transaction c on a.transaction_no=c.transaction_no join patient b 
 on c.id_patient=b.id_patient where a.id_payment='$id_payment'");
  foreach ($query->result() as $m) :?>
<?php $nominal=$m->nominal; ?>
                                                  
<table id="tb">
  <tr>
    <td width="18%"> Date</td>
    <td width="82%">: <?= $m->transaction_date; ?></td>
  </tr>
  <tr>
    <td>Transaction No</td>
    <td>: <?= $m->transaction_no; ?></td>
  </tr>
  <tr>
    <td>Payment No</td>
    <td>: PAY-00<?= $m->id_payment; ?></td>
  </tr>
  <tr>
    <td>Patient</td>
    <td>: <?= $m->patient_name; ?></td>
  </tr>
</table>
<?php endforeach; ?>
<p>
 
 <?php 

function rupiah($angka){
  
  $hasil_rupiah = "Rp. " . number_format($angka,2,',','.');
  return $hasil_rupiah;

}
?>

<table id="customers">
                                   <thead>
                                        <tr >
                                         <th>No</th>
                                            <th>Item/Service</th>
                                            <th>Qty</th>
                                            <th>Price</th>
                                            <th>Discount</th>
                                            <th>Sub Total</th>
                                           
                                        </tr>
  </thead>
                                    <tbody>
                                    <?php $no=1;
                                    $total=0;
                                    $sub=0; ?>
                  <?php foreach($dt_transaction as $d): ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo $no++; ?></td>
                  <td><?= $d->item_service; ?></td>
                  <td><?= $d->qty; ?> </td>
                  <td><?= rupiah($d->price); ?> </td>
                  <td><?= $d->discount; ?> % </td>
                  <td><?= rupiah($sub=$d->sub_total); ?> </td>
                                            
                                          

                                        
                                      </tr>
                                      <?php $total=$total+$sub; ?>
                                  
                                             <?php endforeach; ?>
                                           
                                    </tbody>
                                    <tr>
                                        <td colspan="5" align="right"><div align="right">Total</div></td>
                                        <td><?= rupiah($total); ?></td>
                  </tr>
                  <tr>
                                        <td colspan="5" align="right"><div align="right">Payment</div></td>
                                        <td><?= rupiah($nominal); ?></td>
                  </tr>
</table>
 <p align="center"><font size="-2"> --- Thank you for your visit. Please come again ! ---</font></p>
