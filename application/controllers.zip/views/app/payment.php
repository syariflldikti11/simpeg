<?php 

function rupiah($angka){
  
  $hasil_rupiah = "" . number_format($angka,0,',','.');
  return $hasil_rupiah;

}
?>
   <div class="page-breadcrumb">
          <div class="row">
            <div class="col-md-5 align-self-center">
              <h3 class="page-title">Dashboard</h3>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                     <?= $judul; ?>
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
            <div
              class="
                col-md-7
                justify-content-end
                align-self-center
                d-none d-md-flex
              "
            >
             
            </div>
          </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
<div class="row">
            <div class="col-12">
              <div class="card">
                <div class="border-bottom title-part-padding">
                  <h4 class="card-title mb-0"><a  data-bs-toggle="modal"
                        data-bs-target="#bs-example-modal-lg" class="btn btn-info btn-sm"> Add Payment  </a>
                          <?= $id; ?> Total : <?= rupiah($totalp) ; ?></h4>
                </div>
                <div class="card-body">
                  
                  <div class="table-responsive">
                    <table
               id="zero_config"
                      class="table table-striped table-bordered"
                    >
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Payment Date</th>
                          <th>Pay Amount</th>
                        
                          <th><div align="center">Action</div></th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $no=1;
                         $total=0;
                          ?>
                  <?php foreach($dt_payment as $d): ?>
                        <tr>
                          <td><?= $no++; ?></td>
                          <td><?= $d->date_payment; ?></td>
                          <td><?= rupiah($nominal=$d->nominal); ?></td>
                          <td><div align="center">
                          <?php if($this->session->userdata('akses')=='1'):?>
                       <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Delete" onclick="return confirm('Do you really want to delete ?')" href="<?php echo base_url('app/delete_payment/'.$d->id_payment.'/'.$id.'/'.$totalp);?>" class="btn btn-danger btn-xs" ><i class="fa fa-trash"></i> </a><?php endif; ?>
                      <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Print" href="<?php echo base_url('app/print_payment/'.$d->id_payment.'/'.$id);?>" class="btn btn-success btn-xs" ><i class="fa fa-print"></i> </a>
                          </div>
                       
                       
                      </td>
                        </tr>
 <?php $total=$total+$nominal; ?>
                      <?php endforeach; ?>
                      </tbody>
                      <tfoot>
                        <tr>
                        <th colspan="2" style="text-align: right">Total:</th>
                          <th colspan="1" style="text-align: left"><?= rupiah($total); ?></th>
                         
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>

      
          <div
                        class="modal fade"
                        id="bs-example-modal-lg"
                        tabindex="-1"
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Add Payment <br /> <?= rupiah($totalp) ; ?>
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <?php echo validation_errors();
    echo form_open('app/add_payment'); ?>
                            <div class="modal-body">
                           
                  
                        <input
                          type="hidden"
                          class="form-control" name="transaction_no" value="<?= $id; ?>" required
                        />
                        <input
                          type="hidden"
                          class="form-control" name="total" value="<?= $totalp; ?>" required
                        />
                      <div class="mb-3">
                        <label for="disabledTextInput1">Payment Date</label>
                        <input
                          type="date"
                          class="form-control" name="payment_date" value="<?= date('Y-m-d'); ?>" required
                        />
                      </div>
                      
                      <div class="mb-3">
                        <label for="disabledTextInput1">Pay Amount</label>
                        <input
                          type="number"
                          class="form-control" name="nominal" required
                        />
                      </div>
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="btn btn-info"
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>