<?php 

function rupiah($angka){
  
  $hasil_rupiah = "" . number_format($angka,0,',','.');
  return $hasil_rupiah;

}
?>
<?php
function tgl($date){
  // ubah string menjadi format tanggal
  return date('d-m-Y', strtotime($date));
 }
 ?>
   <div class="page-breadcrumb">
          <div class="row">
            <div class="col-md-5 align-self-center">
              <h3 class="page-title">Dashboard</h3>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                     <?= $judul; ?> 
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
            <div
              class="
                col-md-7
                justify-content-end
                align-self-center
                d-none d-md-flex
              "
            >
             
            </div>
          </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
<div class="row">
            <div class="col-12">
              <div class="card">
                <div class="border-bottom title-part-padding">
                  <h4 class="card-title mb-0"><a  data-bs-toggle="modal"
                        data-bs-target="#bs-example-modal-lg" class="btn btn-info btn-sm"> Add   </a></h4>
                </div>
                <div class="card-body">
                  
                  <div class="table-responsive">
                    <table
                      id="zero_config"
                      class="table table-striped table-bordered"
                    >
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Date</th>
                          <th>Transaction No.</th>
                          <th>Patient</th>
                          <th>Total (IDR)</th>
                          <th>Payment (IDR)</th>
                          <th><div align="center">Action</div></th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $no=1; ?>
                  <?php foreach($dt_service_transaction as $d): ?>
                        <tr>
                          <td><?= $no++; ?></td>
                          <td><?= tgl($d->transaction_date); ?></td>
                          <td><?= $d->transaction_no; ?></td>
                          <td><?= $d->patient_number; ?> | <?= $d->patient_name; ?></td>
                          <td><?= rupiah($d->total); ?></td>
                          <td><?= rupiah($payment=$d->payment); ?></td>
                          <td><div align="center">
                   <?php if($this->session->userdata('akses')=='2' && $payment ==0) :?>   <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Delete" onclick="return confirm('Do you really want to delete ?')" href="<?php echo base_url('app/delete_service_transaction/'.$d->transaction_no);?>" class="btn btn-danger btn-xs" ><i class="fa fa-trash"></i> </a>
                      <?php endif; ?>
                         <?php if($this->session->userdata('akses')=='1') :?>   <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Delete" onclick="return confirm('Do you really want to delete ?')" href="<?php echo base_url('app/delete_service_transaction/'.$d->transaction_no);?>" class="btn btn-danger btn-xs" ><i class="fa fa-trash"></i> </a>
                      <?php endif; ?>
                        <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Detail"   class="btn btn-info btn-xs" href="<?php echo base_url('app/detail_transaction/'.$d->transaction_no.'/'.$d->jenis);?>" ><i class="fa fa-list"></i></a>  
                      </div>
                       
                       
                      </td>
                        </tr>
 
                      <?php endforeach; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>





            <div
                        class="modal fade"
                        id="bs-example-modal-lg"
                        tabindex=""
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Add Service Transaction
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/add_service_transaction'); ?>
                    <div class="mb-3">
                        <label for="disabledTextInput1">Patient</label>
                       <select
                    class="select2 form-control custom-select"
                    style="width: 100%; height: 36px" name="id_patient"
                  >
                  <option>Choose</option>
                  <?php foreach ($dt_patient as $c):?>
<option value="<?= $c->id_patient; ?>"><?= $c->patient_number; ?> | <?= $c->patient_name; ?></option>
                  <?php endforeach; ?>

                </select>
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Transaction Date</label>
                        <input
                          type="date" value="<?= date('Y-m-d'); ?>"
                          class="form-control" name="transaction_date" required
                        />
                      </div>
                     
                     
                     
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>