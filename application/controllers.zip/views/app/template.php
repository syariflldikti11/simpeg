<!DOCTYPE html>
<html dir="ltr" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta
      name="keywords"
      content="wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, monster admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, "
    />
    <meta
      name="description"
      content="Monster is powerful and clean admin dashboard template, inpired from Google's Material Design"
    />
    <meta name="robots" content="noindex,nofollow" />
    <title>Aesa App</title>
    <link
      rel="canonical"
      href="https://www.wrappixel.com/templates/monsteradmin/"
    />
    <!-- Favicon icon -->
    <link
      rel="icon"
      type="image/png"
      sizes="16x16"
      href="<?= base_url(); ?>assets/images/favicon.png"
    />
    <!-- Custom CSS -->
    <link
      rel="stylesheet"
      href="<?= base_url(); ?>assets/libs/apexcharts/dist/apexcharts.css"
    />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

      <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
       <link
      rel="stylesheet"
      type="text/css"
      href="<?= base_url(); ?>assets/libs/select2/dist/css/select2.min.css"
    />
    <link href="<?= base_url(); ?>dist/css/style.min.css" rel="stylesheet" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
      <svg
        class="tea lds-ripple"
        width="37"
        height="48"
        viewbox="0 0 37 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M27.0819 17H3.02508C1.91076 17 1.01376 17.9059 1.0485 19.0197C1.15761 22.5177 1.49703 29.7374 2.5 34C4.07125 40.6778 7.18553 44.8868 8.44856 46.3845C8.79051 46.79 9.29799 47 9.82843 47H20.0218C20.639 47 21.2193 46.7159 21.5659 46.2052C22.6765 44.5687 25.2312 40.4282 27.5 34C28.9757 29.8188 29.084 22.4043 29.0441 18.9156C29.0319 17.8436 28.1539 17 27.0819 17Z"
          stroke="#009efb"
          stroke-width="2"
        ></path>
        <path
          d="M29 23.5C29 23.5 34.5 20.5 35.5 25.4999C36.0986 28.4926 34.2033 31.5383 32 32.8713C29.4555 34.4108 28 34 28 34"
          stroke="#009efb"
          stroke-width="2"
        ></path>
        <path
          id="teabag"
          fill="#009efb"
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M16 25V17H14V25H12C10.3431 25 9 26.3431 9 28V34C9 35.6569 10.3431 37 12 37H18C19.6569 37 21 35.6569 21 34V28C21 26.3431 19.6569 25 18 25H16ZM11 28C11 27.4477 11.4477 27 12 27H18C18.5523 27 19 27.4477 19 28V34C19 34.5523 18.5523 35 18 35H12C11.4477 35 11 34.5523 11 34V28Z"
        ></path>
        <path
          id="steamL"
          d="M17 1C17 1 17 4.5 14 6.5C11 8.5 11 12 11 12"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke="#009efb"
        ></path>
        <path
          id="steamR"
          d="M21 6C21 6 21 8.22727 19 9.5C17 10.7727 17 13 17 13"
          stroke="#009efb"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        ></path>
      </svg>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
      <!-- ============================================================== -->
      <!-- Topbar header - style you can find in pages.scss -->
      <!-- ============================================================== -->
      <header class="topbar">
        <nav class="navbar top-navbar navbar-expand-lg navbar-dark">
          <div class="navbar-header">
            <!-- This is for the sidebar toggle which is visible on mobile only -->
            <a
              class="nav-toggler waves-effect waves-light d-block d-lg-none"
              href="javascript:void(0)"
              ><i class="ti-menu ti-close"></i
            ></a>
            <!-- ============================================================== -->
            <!-- Logo -->
            <!-- ============================================================== -->
            <a class="navbar-brand" href="<?= base_url('app/index'); ?>">
              <!-- Logo icon -->
              <b class="logo-icon">
                <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                <!-- Dark Logo icon -->
                <img
                  src="<?= base_url(); ?>assets/images/logo-light-iconpng"
                  alt="homepage"
                  class="dark-logo"
                />
                <!-- Light Logo icon -->
                <img
                  src="<?= base_url(); ?>assets/images/logo-light-icon.png"
                  alt="homepage"
                  class="light-logo"
                />
              </b>
              <!--End Logo icon -->
              <!-- Logo text -->
              <span class="logo-text">
                <!-- dark Logo text -->
                <img
                  src="<?= base_url(); ?>assets/images/logo-text.png"
                  alt="homepage"
                  class="dark-logo"
                />
                <!-- Light Logo text -->
                <img
                  src="<?= base_url(); ?>assets/images/logo-light-text.png"
                  class="light-logo"
                  alt="homepage"
                />
              </span>
            </a>
            <!-- ============================================================== -->
            <!-- End Logo -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Toggle which is visible on mobile only -->
            <!-- ============================================================== -->
            <a
              class="topbartoggler d-block d-lg-none waves-effect waves-light"
              href="javascript:void(0)"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
              ><i class="ti-more"></i
            ></a>
          </div>
          <!-- ============================================================== -->
          <!-- End Logo -->
          <!-- ============================================================== -->
          <div class="navbar-collapse collapse" id="navbarSupportedContent">
            <!-- ============================================================== -->
            <!-- toggle and nav items -->
            <!-- ============================================================== -->
            <ul class="navbar-nav me-auto">
              <li class="nav-item d-none d-lg-block">
                <a
                  class="nav-link sidebartoggler waves-effect waves-light"
                  href="javascript:void(0)"
                  data-sidebartype="mini-sidebar"
                  ><i class="icon-arrow-left-circle"></i
                ></a>
              </li>
              <!-- ============================================================== -->
              <!-- Comment -->
              <!-- ============================================================== -->
            
              <!-- ============================================================== -->
              <!-- End Comment -->
              <!-- ============================================================== -->
              <!-- ============================================================== -->
              <!-- Messages -->
              <!-- ============================================================== -->
            
              <!-- ============================================================== -->
              <!-- End Messages -->
              <!-- ============================================================== -->
              <!-- ============================================================== -->
              <!-- mega menu -->
              <!-- ============================================================== -->
           
              <!-- ============================================================== -->
              <!-- End mega menu -->
              <!-- ============================================================== -->
            </ul>
            <!-- ============================================================== -->
            <!-- Right side toggle and nav items -->
            <!-- ============================================================== -->
            <ul class="navbar-nav">
              <!-- ============================================================== -->
              <!-- Search -->
              <!-- ============================================================== -->
        
              <!-- ============================================================== -->
              <!-- User profile and search -->
              <!-- ============================================================== -->
             
              <!-- ============================================================== -->
              <!-- User profile and search -->
              <!-- ============================================================== -->
              <!-- ============================================================== -->
              <!-- Language  -->
              <!-- ============================================================== -->
           
            </ul>
          </div>
        </nav>
      </header>
      <!-- ============================================================== -->
      <!-- End Topbar header -->
      <!-- ============================================================== -->
      <!-- ============================================================== -->
      <!-- Left Sidebar - style you can find in sidebar.scss  -->
      <!-- ============================================================== -->
      <aside class="left-sidebar">
        <!-- Sidebar scroll-->
        <div class="scroll-sidebar">
          <!-- Sidebar navigation-->
          <nav class="sidebar-nav">
            <ul id="sidebarnav">
              <!-- User Profile-->
             
              <li class="sidebar-item">
                <a
                  class="sidebar-link"
                  href="<?= base_url('app'); ?>"
                  aria-expanded="false"
                  ><i data-feather="home" class="feather-icon"></i
                  ><span class="hide-menu">Dashboard </span></a
                >
               
              </li>
              <?php  if($this->session->userdata('akses')=='2' ) :?> 
              <li class="sidebar-item">
                <a
                  class="sidebar-link"
                  href="<?= base_url('app/patient'); ?>"
                  aria-expanded="false"
                  ><i data-feather="user" class="feather-icon"></i
                  ><span class="hide-menu">Patient </span></a
                >
               
              </li>
              <?php endif; ?>

              <?php  if($this->session->userdata('akses')=='1' ) :?>    
              <li class="sidebar-item">
                <a
                  class="sidebar-link has-arrow waves-effect waves-dark"
                  href="javascript:void(0)"
                  aria-expanded="false"
                  ><i data-feather="folder" class="feather-icon"></i
                  ><span class="hide-menu">Master Data</span></a
                >
                <ul aria-expanded="false" class="collapse first-level">
                
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      href="<?= base_url('app/beautycian'); ?>"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Beautycian</span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      href="<?= base_url('app/patient'); ?>"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Patient</span></a
                    >
                  </li>
                    <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      href="<?= base_url('app/item_unit'); ?>"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Item Unit</span></a
                    >
                  </li>
                   
                </ul>
              </li>
        
           
              <li class="sidebar-item">
                <a
                  class="sidebar-link has-arrow waves-effect waves-dark"
                  href="javascript:void(0)"
                  aria-expanded="false"
                  ><i data-feather="pocket" class="feather-icon"></i
                  ><span class="hide-menu">Service</span></a
                >
                <ul aria-expanded="false" class="collapse first-level">
                
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      href="<?= base_url('app/service'); ?>"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Service</span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      href="<?= base_url('app/service_package'); ?>"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Service Package</span></a
                    >
                  </li>
                  
                </ul>
              </li>
              
              <li class="sidebar-item">
                <a
                  class="sidebar-link has-arrow waves-effect waves-dark"
                  href="javascript:void(0)"
                  aria-expanded="false"
                  ><i data-feather="grid" class="feather-icon"></i
                  ><span class="hide-menu">Item</span></a
                >
                <ul aria-expanded="false" class="collapse first-level">
                  
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      href="<?= base_url('app/item_name'); ?>"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Item Name</span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      href="<?= base_url('app/incoming_item'); ?>"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Incoming Item</span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      href="<?= base_url('app/item_list'); ?>"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Item List</span></a
                    >
                  </li>
                </ul>
              </li>
            <?php endif; ?>
           
              <li class="sidebar-item">
                <a
                  class="sidebar-link has-arrow waves-effect waves-dark"
                  href="javascript:void(0)"
                  aria-expanded="false"
                  ><i data-feather="file-text" class="feather-icon"></i
                  ><span class="hide-menu">Transaction</span></a
                >
                <ul aria-expanded="false" class="collapse first-level">
                  
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      href="<?= base_url('app/service_transaction'); ?>"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Service </span></a
                    >
                  </li>
                   <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      href="<?= base_url('app/package_transaction'); ?>"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Service Package</span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      href="<?= base_url('app/item_transaction'); ?>"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Item Sell</span></a
                    >
                  </li>
                </ul>
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link"
                  href="<?= base_url('app/therapist_schedule'); ?>"
                  aria-expanded="false"
                  ><i data-feather="calendar" class="feather-icon"></i
                  ><span class="hide-menu"> Schedule </span></a
                >
               
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link"
                  href="<?= base_url('app/commission'); ?>"
                  aria-expanded="false"
                  ><i data-feather="gift" class="feather-icon"></i
                  ><span class="hide-menu">Commission </span></a
                >
               
              </li>
              <?php  if($this->session->userdata('akses')=='1' ) :?>   
              <li class="sidebar-item">
                <a
                  class="sidebar-link has-arrow waves-effect waves-dark"
                  href="javascript:void(0)"
                  aria-expanded="false"
                  ><i data-feather="book" class="feather-icon"></i
                  ><span class="hide-menu">Report</span></a
                >
                <ul aria-expanded="false" class="collapse first-level">
                  
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      data-bs-toggle="modal"
                        data-bs-target="#bs-service-lg"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Service</span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      data-bs-toggle="modal"
                        data-bs-target="#bs-service-package-lg"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Service Package</span></a
                    >
                  </li>
                  <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      data-bs-toggle="modal"
                        data-bs-target="#bs-item-lg"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Item Sell</span></a
                    >
    </li>
    <li class="sidebar-item">
                    <a
                      class="sidebar-link waves-effect waves-dark sidebar-link"
                      data-bs-toggle="modal"
                        data-bs-target="#bs-salary-lg"
                      aria-expanded="false"
                      ><i class="mdi mdi-adjust"></i
                      ><span class="hide-menu">Salary</span></a
                    >
                  </li>
                  
                 
                </ul>
                
              </li>
              <?php endif; ?>
              <li class="sidebar-item">
                <a
                  class="sidebar-link"
                  href="<?= base_url('login/logout'); ?>"
                  aria-expanded="false"
                  ><i data-feather="log-out" class="feather-icon"></i
                  ><span class="hide-menu">Logout</span></a
                >
               
              </li>
       
            
            </ul>
          </nav>
          <!-- End Sidebar navigation -->
        </div>

        <!-- End Sidebar scroll-->
      </aside>

     
      <!-- ============================================================== -->
      <!-- End Left Sidebar - style you can find in sidebar.scss  -->
      <!-- ============================================================== -->
      <!-- ============================================================== -->
      <!-- Page wrapper  -->
      <!-- ============================================================== -->
      <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
     

        <?=$contents ?>
        
       
  
      
        </div>
        <div
                        class="modal fade"
                        id="bs-service-lg"
                        tabindex=""
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Report Service Transaction
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/report_service_transaction'); ?>
                   
                      <div class="mb-3">
                        <label for="disabledTextInput1">From</label>
                        <input
                          type="date" value="<?= date('Y-m-d'); ?>"
                          class="form-control" name="dari" required
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Until</label>
                        <input
                          type="date" value="<?= date('Y-m-d'); ?>"
                          class="form-control" name="sampai" required
                        />
                      </div>
                     
                     
                     
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>

                    <div
                        class="modal fade"
                        id="bs-service-package-lg"
                        tabindex=""
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Report Service Package Transaction
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/report_service_transaction'); ?>
                   
                      <div class="mb-3">
                        <label for="disabledTextInput1">From</label>
                        <input
                          type="date" value="<?= date('Y-m-d'); ?>"
                          class="form-control" name="dari" required
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Until</label>
                        <input
                          type="date" value="<?= date('Y-m-d'); ?>"
                          class="form-control" name="sampai" required
                        />
                      </div>
                     
                     
                     
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>

                    <div
                        class="modal fade"
                        id="bs-item-lg"
                        tabindex=""
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Report Item Sell Transaction
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/report_item_transaction'); ?>
                   
                      <div class="mb-3">
                        <label for="disabledTextInput1">From</label>
                        <input
                          type="date" value="<?= date('Y-m-d'); ?>"
                          class="form-control" name="dari" required
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Until</label>
                        <input
                          type="date" value="<?= date('Y-m-d'); ?>"
                          class="form-control" name="sampai" required
                        />
                      </div>
                     
                     
                     
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>

                    <div
                        class="modal fade"
                        id="bs-salary-lg"
                        tabindex=""
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Report Salary Beautycian
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/report_salary'); ?>
                   
                   <div class="mb-3">
                        <label for="disabledTextInput1">Beautycian</label>
                 
                          <select
                    class="select2 form-control custom-select"
                    style="width: 100%; height: 36px" name="id_beautycian"
                  >
                
                  <?php
                               
                               $query=$this->db->query("Select * from beautycian where status=1");
                               foreach ($query->result() as $c) :?>
<option value="<?= $c->id_beautycian; ?>"><?= $c->name; ?></option>
                  <?php endforeach; ?>

                </select>
                          </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">From</label>
                        <input
                          type="date" value="<?= date('Y-m-d'); ?>"
                          class="form-control" name="dari" required
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Until</label>
                        <input
                          type="date" value="<?= date('Y-m-d'); ?>"
                          class="form-control" name="sampai" required
                        />
                      </div>
                     
                     
                     
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>
        <!-- ============================================================== -->
        <!-- End Container fluid  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <footer class="footer">All right reserved by Amanda Estetika.</footer>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
      </div>
      <!-- ============================================================== -->
      <!-- End Page wrapper  -->
      <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- customizer Panel -->
    <!-- ============================================================== -->
    <aside class="customizer">
      <a href="javascript:void(0)" class="service-panel-toggle"
        ><i class="fa fa-spin fa-cog"></i
      ></a>
      <div class="customizer-body">
        <ul class="nav customizer-tab" role="tablist">
          <li class="nav-item">
            <a
              class="nav-link active"
              id="pills-home-tab"
              data-bs-toggle="pill"
              href="#pills-home"
              role="tab"
              aria-controls="pills-home"
              aria-selected="true"
              ><i class="mdi mdi-wrench fs-6"></i
            ></a>
          </li>
    
          
        </ul>
        <div class="tab-content" id="pills-tabContent">
          <!-- Tab 1 -->
          <div
            class="tab-pane fade show active"
            id="pills-home"
            role="tabpanel"
            aria-labelledby="pills-home-tab"
          >
            <div class="p-3 border-bottom">
              <!-- Sidebar -->
              <h5 class="font-weight-medium mb-2 mt-2">Layout Settings</h5>
              <div class="form-check mt-3">
                <input
                  type="checkbox"
                  name="theme-view"
                  class="form-check-input"
                  id="theme-view"
                />
                <label class="form-check-label" for="theme-view">
                  <span>Dark Theme</span>
                </label>
              </div>
              
           
            
              <div class="form-check mt-2">
                <input
                  type="checkbox"
                  name="boxed-layout"
                  class="form-check-input"
                  id="boxed-layout"
                />
                <label class="form-check-label" for="boxed-layout">
                  <span>Boxed Layout</span>
                </label>
              </div>
            </div>
            <div class="p-3 border-bottom">
              <!-- Logo BG -->
              <h5 class="font-weight-medium mb-2 mt-2">Logo Backgrounds</h5>
              <ul class="theme-color m-0 p-0">
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-logobg="skin1"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-logobg="skin2"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-logobg="skin3"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-logobg="skin4"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-logobg="skin5"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-logobg="skin6"
                  ></a>
                </li>
              </ul>
              <!-- Logo BG -->
            </div>
            <div class="p-3 border-bottom">
              <!-- Navbar BG -->
              <h5 class="font-weight-medium mb-2 mt-2">Navbar Backgrounds</h5>
              <ul class="theme-color m-0 p-0">
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-navbarbg="skin1"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-navbarbg="skin2"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-navbarbg="skin3"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-navbarbg="skin4"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-navbarbg="skin5"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-navbarbg="skin6"
                  ></a>
                </li>
              </ul>
              <!-- Navbar BG -->
            </div>
            <div class="p-3 border-bottom">
              <!-- Logo BG -->
              <h5 class="font-weight-medium mb-2 mt-2">Sidebar Backgrounds</h5>
              <ul class="theme-color m-0 p-0">
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-sidebarbg="skin1"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-sidebarbg="skin2"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-sidebarbg="skin3"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-sidebarbg="skin4"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-sidebarbg="skin5"
                  ></a>
                </li>
                <li class="theme-item list-inline-item me-1">
                  <a
                    href="javascript:void(0)"
                    class="theme-link rounded-circle d-block"
                    data-sidebarbg="skin6"
                  ></a>
                </li>
              </ul>
              <!-- Logo BG -->
            </div>
          </div>
          <!-- End Tab 1 -->
          <!-- Tab 2 -->
        
          
          </div>
          <!-- End Tab 2 -->
          <!-- Tab 3 -->
         
       
            
          </div>
          <!-- End Tab 3 -->
        </div>
      </div>
    </aside>

    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?= base_url(); ?>assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?= base_url(); ?>assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="<?= base_url(); ?>dist/js/app.min.js"></script>
    <script src="<?= base_url(); ?>dist/js/app.init.horizontal.js"></script>
    <script src="<?= base_url(); ?>dist/js/app-style-switcher.horizontal.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?= base_url(); ?>assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="<?= base_url(); ?>assets/libs/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!--Wave Effects -->
    <script src="<?= base_url(); ?>dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?= base_url(); ?>dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="<?= base_url(); ?>dist/js/feather.min.js"></script>
    <script src="<?= base_url(); ?>dist/js/custom.min.js"></script>

    <script src="<?= base_url(); ?>dist/js/pages/dashboards/dashboard1.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?= base_url(); ?>assets/libs/select2/dist/js/select2.full.min.js"></script>
    <script src="<?= base_url(); ?>assets/libs/select2/dist/js/select2.min.js"></script>
    <script src="<?= base_url(); ?>dist/js/pages/forms/select2/select2.init.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
      <script type="text/javascript">
    <?php if($this->session->flashdata('success')){ ?>
    toastr.success("<?php echo $this->session->flashdata('success'); ?>");
<?php }else if($this->session->flashdata('delete')){  ?>
    toastr.error("<?php echo $this->session->flashdata('delete'); ?>");
<?php }else if($this->session->flashdata('update')){  ?>
    toastr.info("<?php echo $this->session->flashdata('update'); ?>");
<?php } ?>
</script>
<script>
$(document).ready(function(){
  $('[data-tooltip="tooltip"]').tooltip();   
});
</script>
<script>
        //setting datatables
        $('#zero_config').DataTable({
        });
    </script>
<script type="text/javascript">
    var table;
    $(document).ready(function() {
 
        //datatables
        table = $('#tb_patient').DataTable({ 
 
            "processing": true, 
            "serverSide": true, 
            "order": [], 
             
            "ajax": {
                "url": "<?php echo site_url('app/ajax_list')?>",
                "type": "POST"
            },
 
             
            "columnDefs": [
            { 
                "targets": [ 0 ], 
                "orderable": false, 
            },
            ],
 
        });
 
    });
 
</script>
<script type="text/javascript">
    var table;
    $(document).ready(function() {
 
        //datatables
        table = $('#tb_patient_admin').DataTable({ 
 
            "processing": true, 
            "serverSide": true, 
            "order": [], 
             
            "ajax": {
                "url": "<?php echo site_url('app/ajax_list_admin')?>",
                "type": "POST"
            },
 
             
            "columnDefs": [
            { 
                "targets": [ 0 ], 
                "orderable": false, 
            },
            ],
 
        });
 
    });
 
</script>
<script type="text/javascript">
jQuery(function(){
 new Highcharts.Chart({
  chart: {
   renderTo: 'chart',
   type: 'column',
  },
  title: {
   text: '',
   x: -20
  },
  subtitle: {
   text: '',
   x: -20
  },
  xAxis: {
   categories: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
                    'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des']
  },
  yAxis: {
   title: {
    text: 'Total Transactions'
   }
  },
  series: [{
   name: 'Item Sell',
   data: <?php echo json_encode($grafik_penjualan); ?>
 
  },
  {
     name: 'Service',

       data: <?php echo json_encode($grafik_service); ?>
  }
  ,
  {
     name: 'Service Package',

       data: <?php echo json_encode($grafik_service_package); ?>
  }
  ]
 });
}); 
</script>
  </body>
</html>
