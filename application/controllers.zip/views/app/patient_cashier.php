   
      <?php 

function rupiah($angka){
  
  $hasil_rupiah = "" . number_format($angka,0,',','.');
  return $hasil_rupiah;

}
?><div class="page-breadcrumb">
          <div class="row">
            <div class="col-md-5 align-self-center">
              <h3 class="page-title">Dashboard</h3>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                     <?= $judul; ?>
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
            <div
              class="
                col-md-7
                justify-content-end
                align-self-center
                d-none d-md-flex
              "
            >
             
            </div>
          </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
<div class="row">
            <div class="col-12">
              <div class="card">
                <div class="border-bottom title-part-padding">
                  <h4 class="card-title mb-0"><a  data-bs-toggle="modal"
                   data-bs-target="#bs-example-modal-lg" class="btn btn-info btn-sm"> Add </a>
                </div>
                <div class="card-body">
                  
                  <div class="table-responsive">
                    <table
                      id="tb_patient"
                      class="table table-striped table-bordered"
                    >
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Patient Number</th>
                          <th>Name</th>
                          <th>Gender</th>
                          <th>Place of Birth</th>
                          <th>Address</th>
                          
                          <th>Action</th>
                        
                        </tr>
                      </thead>
                     
 

                      
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>





            <div
                        class="modal fade"
                        id="bs-example-modal-lg"
                        tabindex="-1"
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Add patient
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/add_patient'); ?>
                    <div class="mb-3">
                        <label for="disabledTextInput1">Patient Number</label>
                        <input
                          type="text"
                          class="form-control" name="patient_number" required
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Name</label>
                        <input
                          type="text"
                          class="form-control" name="patient_name" required
                        />
                      </div>
                      <div class="mb-3">
                        <label for="">Gender</label>
                        <select class="form-select" name="patient_gender">
                          <option value="L">L</option>
                          <option value="P">P</option>
                        </select>
                      </div>
                 <div class="mb-3">
                        <label for="disabledTextInput1">Place of Birth</label>
                        <input
                          type="text"
                          class="form-control" name="patient_pob" required
                        />
                      </div>
                       <div class="mb-3">
                        <label for="disabledTextInput1">Address</label>
                        <input
                          type="text"
                          class="form-control" name="patient_address" required
                        />
                      </div>
                       <div class="mb-3">
                        <label for="disabledTextInput1">Phone</label>
                        <input
                          type="number"
                          class="form-control" name="patient_phone" required
                        />
                      </div>
                     
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>

                   