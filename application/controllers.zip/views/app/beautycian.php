      <?php 

function rupiah($angka){
  
  $hasil_rupiah = "" . number_format($angka,0,',','.');
  return $hasil_rupiah;

}
?>
   <div class="page-breadcrumb">
          <div class="row">
            <div class="col-md-5 align-self-center">
              <h3 class="page-title">Dashboard</h3>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                     <?= $judul; ?>
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
            <div
              class="
                col-md-7
                justify-content-end
                align-self-center
                d-none d-md-flex
              "
            >
             
            </div>
          </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
<div class="row">
            <div class="col-12">
              <div class="card">
                <div class="border-bottom title-part-padding">
                  <h4 class="card-title mb-0"><a  data-bs-toggle="modal"
                        data-bs-target="#bs-example-modal-lg" class="btn btn-info btn-sm"> Add </a></h4>
                </div>
                <div class="card-body">
                  
                  <div class="table-responsive">
                    <table
                      id="zero_config"
                      class="table table-striped table-bordered"
                    >
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Name</th>
                          <th>Gender</th>
                          <th>Place of Birth</th>
                          <th>Address</th>
                          <th>Phone</th>
                          <th>Base Salary</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $no=1; ?>
                  <?php foreach($dt_beautycian as $d): ?>
                        <tr>
                          <td><?= $no++; ?></td>
                          <td><?= $d->name; ?></td>
                          <td><?= $d->gender; ?></td>
                          <td><?= $d->place_of_birth; ?></td>
                          <td><?= $d->address; ?></td>
                          <td><?= $d->phone; ?></td>
                          <td><?= rupiah($d->base_salary) ?></td>
                          <td><?php if($d->status==1) {
                            echo '<font color="green">Active</font>';
                          } 
                          else  echo '<font color="red">Non Active</font>';
                            ?></td>
                          <td>
                       <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Delete" onclick="return confirm('Do you really want to delete ?')" href="<?php echo base_url('app/delete_beautycian/'.$d->id_beautycian);?>" class="btn btn-danger btn-xs" ><i class="fa fa-trash"></i></a>  
                        <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="update"  data-bs-toggle="modal"
                        data-bs-target="#edit<?= $d->id_beautycian; ?>"  class="btn btn-info btn-xs" ><i class="fa fa-edit"></i></a>  
                      </td>
                        </tr>
  <div
                        class="modal fade"
                        id="edit<?= $d->id_beautycian; ?>"
                        tabindex="-1"
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Update Beautycian
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/update_beautycian'); ?>
                  <?php
                                                        $id=$d->id_beautycian;
                                                        $query=$this->db->query("Select * from beautycian where id_beautycian='$id'");
                                                        foreach ($query->result() as $a) :?>
                      <div class="mb-3">
                         <input
                          type="hidden"
                          class="form-control" name="id_beautycian" value="<?= $a->id_beautycian; ?>" required
                        />
                        <label for="disabledTextInput1">Name</label>
                        <input
                          type="text"
                          class="form-control" name="name" value="<?= $a->name; ?>" required
                        />
                      </div>
                      <div class="mb-3">
                        <label for="">Gender</label>
                        <select class="form-select" name="gender">
                          <option value="L" <?php if($a->gender=="L") { echo 'selected';} ?>>L</option>
                          <option value="P" <?php if($a->gender=="P") {echo 'selected';} ?>>P</option>
                        </select>
                      </div>
                 <div class="mb-3">
                        <label for="disabledTextInput1">Place of Birth</label>
                        <input
                          type="text"
                          class="form-control" name="place_of_birth" value="<?= $a->place_of_birth; ?>" required
                        />
                      </div>
                       <div class="mb-3">
                        <label for="disabledTextInput1">Address</label>
                        <input
                          type="text"
                          class="form-control" name="address" value="<?= $a->address; ?>" required
                        />
                      </div>
                       <div class="mb-3">
                        <label for="disabledTextInput1">Phone</label>
                        <input
                          type="number"
                          class="form-control" name="phone" value="<?= $a->phone; ?>" required
                        />
                      </div>
                       <div class="mb-3">
                        <label for="disabledTextInput1">Base Salary</label>
                        <input
                          type="number"
                          class="form-control" name="base_salary" value="<?= $a->base_salary; ?>" required
                        />
                      </div>
                       <div class="mb-3">
                        <label for="">Status</label>
                        <select class="form-select" name="status">
                          <option value="1" <?php if($a->status=="1") { echo 'selected';} ?>>Active</option>
                          <option value="0" <?php if($a->status=="0") {echo 'selected';} ?>>Non Active</option>
                        </select>
                      </div>
                     <?php endforeach; ?>
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Update"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>

                      <?php endforeach; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>





            <div
                        class="modal fade"
                        id="bs-example-modal-lg"
                        tabindex="-1"
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Add Beautycian
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/add_beautycian'); ?>
                  
                      <div class="mb-3">
                        <label for="disabledTextInput1">Name</label>
                        <input
                          type="text"
                          class="form-control" name="name" required
                        />
                      </div>
                      <div class="mb-3">
                        <label for="">Gender</label>
                        <select class="form-select" name="gender">
                          <option value="L">L</option>
                          <option value="P">P</option>
                        </select>
                      </div>
                 <div class="mb-3">
                        <label for="disabledTextInput1">Place of Birth</label>
                        <input
                          type="text"
                          class="form-control" name="place_of_birth" required
                        />
                      </div>
                       <div class="mb-3">
                        <label for="disabledTextInput1">Address</label>
                        <input
                          type="text"
                          class="form-control" name="address" required
                        />
                      </div>
                       <div class="mb-3">
                        <label for="disabledTextInput1">Phone</label>
                        <input
                          type="number"
                          class="form-control" name="phone" required
                        />
                      </div>
                       <div class="mb-3">
                        <label for="disabledTextInput1">Base Salary</label>
                        <input
                          type="number"
                          class="form-control" name="base_salary" required
                        />
                      </div>
                     
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>