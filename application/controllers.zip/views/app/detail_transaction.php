<?php 

function rupiah($angka){
  
  $hasil_rupiah = "" . number_format($angka,0,',','.');
  return $hasil_rupiah;

}
?>
<?php
function tgl($date){
  // ubah string menjadi format tanggal
  return date('d-m-Y', strtotime($date));
 }
 ?>

   <div class="page-breadcrumb">
          <div class="row">
            <div class="col-md-5 align-self-center">
              <h3 class="page-title">Dashboard</h3>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                     <?= $judul; ?>
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
            <div
              class="
                col-md-7
                justify-content-end
                align-self-center
                d-none d-md-flex
              "
            >
             
            </div>
          </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <?php
                                                        
                                                        $cek=$this->db->query("Select payment from transaction where transaction_no='$id'");
                                                        foreach ($cek->result() as $pm) :?>
                  <?php  $pm=$pm->payment; ?>
                <?php endforeach; ?>
        <div class="container-fluid">

<div class="row">
            <div class="col-12">
              <div class="card">
                <div class="border-bottom title-part-padding">
                 
                  <h4 class="card-title mb-0"><?php if($this->session->userdata('akses')=='2' && $pm ==0) :?><?php if($jenis < 2):?><a  data-bs-toggle="modal"
                        data-bs-target="#bs-service" class="btn btn-info btn-sm"> Add Service  </a><?php endif; ?> <a  data-bs-toggle="modal"
                        data-bs-target="#bs-item" class="btn btn-info btn-sm"> Add Item  </a>  <?php if($jenis ==2 ):?><?php endif; ?> <?php endif; ?>
                           <?php if($jenis ==2 && $this->session->userdata('akses')=='2') :?><a  data-bs-toggle="modal"
                        data-bs-target="#bs-package" class="btn btn-info btn-sm"> Add Service Package  </a>
                      <a  data-bs-toggle="modal"
                        data-bs-target="#bs-item" class="btn btn-info btn-sm"> Add Item  </a><?php endif; ?> </h4>
                     

                       <?php if($this->session->userdata('akses')=='1') :?>
                  <h4 class="card-title mb-0"><?php if($jenis < 2):?><a  data-bs-toggle="modal"
                        data-bs-target="#bs-service" class="btn btn-info btn-sm"> Add Service  </a><?php endif; ?> <a  data-bs-toggle="modal"
                        data-bs-target="#bs-item" class="btn btn-info btn-sm"> Add Item  </a>  <?php if($jenis ==2 ):?><a  data-bs-toggle="modal"
                        data-bs-target="#bs-package" class="btn btn-info btn-sm"> Add Service Package  </a><?php endif; ?>  </h4>
                      <?php endif; ?>
                      <b><?= $id; ?></b>
                </div>
                <div class="card-body">
                  
                  <div class="table-responsive">
                    <table
               id="zero_config"
                      class="table table-striped table-bordered"
                    >
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Work Date</th>
                          <th>Item/Service</th>
                          <?php if($jenis !=2 ):?><th>Price (IDR)</th><?php endif; ?>
                          <th>Qty</th>
                          <?php if($jenis !=2 ):?> <th>Discount</th><?php endif; ?>
                            <?php if($jenis !=2 ):?> <th>Total (IDR)</th><?php endif; ?>
                          <th><div align="center">Action</div></th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $no=1;
                         $total=0;
                         $sub=0;
                          ?>
                  <?php foreach($dt_transaction as $d): ?>
                        <tr>
                          <td><?= $no++; ?></td>
                          <td><?= tgl($d->work_date); ?></td>
                          <td><?= $d->item_service; ?></td>
                          <?php if($jenis !=2 ):?> <td><?= rupiah($d->price); ?></td><?php endif; ?>
                          <td><?= $d->qty; ?></td>
                          <?php if($jenis !=2 ):?> <td><?= $d->discount; ?> %</td><?php endif; ?>
                            <?php if($jenis !=2 ):?> <td><?= rupiah($sub=$d->sub_total); ?></td><?php endif; ?>
                          <td><div align="center">
                           <?php if($this->session->userdata('akses')=='2' && $pm ==0) :?>
                       <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Delete" onclick="return confirm('Do you really want to delete ?')" href="<?php echo base_url('app/delete_detail_transaction/'.$d->id_detail_transaction.'/'.$id.'/'.$jenis);?>" class="btn btn-danger btn-xs" ><i class="fa fa-trash"></i> </a>
                      <?php endif; ?> 
                      <?php if($this->session->userdata('akses')=='1' ) :?>
                       <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Delete" onclick="return confirm('Do you really want to delete ?')" href="<?php echo base_url('app/delete_detail_transaction/'.$d->id_detail_transaction.'/'.$id.'/'.$jenis);?>" class="btn btn-danger btn-xs" ><i class="fa fa-trash"></i> </a> 
                      
                        <?php endif; ?>
                      <?php if($d->detail_item !=3 ):?> 
                        <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Edit"  data-bs-toggle="modal"
                        data-bs-target="#editservice<?= $d->id_detail_transaction; ?>"  class="btn btn-success btn-xs" ><i class="fa fa-edit"></i></a>
                        <?php endif; ?>
                        

                       

                        <?php if($jenis <3 ):?>
                        <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Therapist"  data-bs-toggle="modal"
                        data-bs-target="#edit<?= $d->id_detail_transaction; ?>"  class="btn btn-info btn-xs" ><i class="fa fa-user"></i></a>
                        <?php endif; ?>
                    </div>
                       
                       
                      </td>
                        </tr>
 <?php $total=$total+$sub; ?>



 <div
                        class="modal fade"
                        id="editservice<?= $d->id_detail_transaction; ?>"
                        tabindex=""
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Edit Therapist
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <?php
                                                        $ids=$d->id_detail_transaction;
                                                        $edit=$this->db->query("Select * from detail_transaction where id_detail_transaction='$ids'");
                                                        foreach ($edit->result() as $k) :?>
                  <?php $svc=$k->item_service; ?>
                            <div class="modal-body">

    <form name="myFormed" action="<?= base_url('app/edit_detail_service_transaction'); ?>" onsubmit="return validateFormed()"  method="post">
    <input
                          type="hidden" 
                        name="id_detail_transaction" value="<?= $k->id_detail_transaction; ?>"
                        />
                      <input
                          type="hidden" 
                        name="transaction_no" value="<?= $k->transaction_no; ?>"
                        />
                        <input
                          type="hidden" 
                        name="jenis" value="<?= $jenis; ?>"
                        />
                       
                     
                        <div class="mb-3">
                        <label for="disabledTextInput1">Service</label>
                        <input
                          type="text" 
                          class="form-control" class="form-control" name="price"  value="<?= $k->item_service; ?>" readonly
                        />
</div>
                     
                       
                        <div class="mb-3">
                        <label for="disabledTextInput1">Work Date</label>
                        <input
                          type="date" 
                          class="form-control"  name="work_date" value="<?= $k->work_date; ?>"
                        />
                      </div>
                      <?php if($jenis==1) :?>
                      <?php
                                                     
                                                      
                                                        $sv=$this->db->query("Select * from service where service_name='$svc'");
                                                  
                                                        foreach ($sv->result() as $h) :?>
                     
                        <input
                          type="text" 
                          class="form-control" name="main_commissioned"  style="display:none;" value="<?= $h->main_commission; ?>"  readonly
                        />
                    
                      <div class="mb-3">
                        <label for="disabledTextInput1">Assist Commission</label>
                        <input
                          type="text" 
                          class="form-control" name="assist_commissioned"  style="display:none;" value="<?= $h->assist_commission; ?>"  readonly
                        />
                      </div>
                      
                      <?php endforeach; ?>
                      <?php endif; ?>
                      <?php if($jenis==2) :?>
                      <?php
                                                   
                                                        $sv=$this->db->query("Select * from service_package where package_name='$svc'");
                                                  
                                                        foreach ($sv->result() as $h) :?>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Main Commission</label>
                        <input
                          type="text" 
                          class="form-control" name="main_commissioned" value="<?= $h->main_commission; ?>"  readonly
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Assist Commission</label>
                        <input
                          type="text" 
                          class="form-control" name="assist_commissioned" value="<?= $h->assist_commission; ?>"  readonly
                        />
                      </div>
                      
                      <?php endforeach; ?>
                      <?php endif; ?>
                     
                      <div class="mb-3">
                        <label for="disabledTextInput1">Main Therapist</label>
                       <select
                    class="select2 form-control custom-select"
                    style="width: 100%; height: 36px" name="main_therapisted"
                  >
                  <option value="0">Choose</option>
                  <?php foreach ($dt_beautycian as $p):?>
<option value="<?= $p->id_beautycian; ?>"><?= $p->name; ?></option>
                  <?php endforeach; ?>

                </select>
                      </div>

                      <div class="mb-3">
                        <label for="disabledTextInput1">Assist</label>
                       <select
                    class="select2 form-control custom-select"
                    style="width: 100%; height: 36px" name="assist_therapisted"
                  >
<option value="0">Choose</option>
                  <?php foreach ($dt_beautycian as $q):?>
<option value="<?= $q->id_beautycian; ?>"><?= $q->name; ?></option>
                  <?php endforeach; ?>

                </select>
                      </div>
                     
                     
                     
                  
                            </div>
                            <?php endforeach; ?>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>

















 <div
                        class="modal fade"
                        id="edit<?= $d->id_detail_transaction; ?>"
                        tabindex="-1"
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                              Therapist
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/update_service'); ?>
                  <?php
                                                        $query=$this->db->query("Select * from main_commission a join beautycian b on a.id_beautycian=b.id_beautycian where id_detail_transaction='$ids'");
                                                        foreach ($query->result() as $m) :?>
                  

                      <div class="mb-3">
                        <label for="disabledTextInput1">Main Therapist</label>
                        <input
                          type="text"
                          class="form-control"  value="<?= $m->name; ?>" readonly
                        />
                      </div>
                      <?php endforeach; ?>
                      <?php
                                                        
                                                        $queryy=$this->db->query("Select * from assist_commission a join beautycian b on a.id_beautycian=b.id_beautycian where id_detail_transaction='$ids'");
                                                        foreach ($queryy->result() as $n) :?>
                 <div class="mb-3">
                        <label for="disabledTextInput1">Asist Therapist</label>
                        <input
                          type="text"
                          class="form-control"  value="<?= $n->name; ?>" readonly
                        />
                      </div>
                      <?php endforeach; ?>
                     
                    
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>
                      <?php endforeach; ?>
                      </tbody>
                      <?php if($jenis !=2 ):?> <tfoot>
                        <tr>
                        <th colspan="6" style="text-align: right">Total:</th>
                          <th colspan="2" style="text-align: left">
                              <?= rupiah($total); ?>  <?php if($this->session->userdata('akses')=='2' ) :?> <?php if($total!=$pm):?><a   class="btn btn-success btn-xs" href="<?php echo base_url('app/payment/'.$id.'/'.$total);?>" >Add payment</a><?php endif; ?> <?php endif; ?>
                              <?php if($this->session->userdata('akses')=='1' ) :?>
                              <a   class="btn btn-success btn-xs" href="<?php echo base_url('app/payment/'.$id.'/'.$total);?>" >Add payment</a>
                              <?php endif; ?>
                              </th>
                         
                        </tr>
                      </tfoot><?php endif; ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>

        

          <div
                        class="modal fade"
                        id="bs-service"
                        tabindex=""
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Add Service
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">

    <form name="myForm" action="<?= base_url('app/add_detail_service_transaction'); ?>" onsubmit="return validateForm()" method="post">
                    <div class="mb-3">
                        <label for="disabledTextInput1">Service</label>
                        <select class="select2 form-control custom-select"
                    style="width: 100%; height: 36px"  onchange="changeValue(this.value)">
                    <option>Pilih</option>
                      
                          <?php

$jsArray = "var prdName = new Array();\n";
foreach ($dt_service as $c) {

echo '<option   value="' . $c->id_service . '">' . $c->service_name . '</option>';  
$jsArray .= "prdName['" . $c->id_service . "'] = {service:'" . addslashes($c->service_name) . "',service_price:'".addslashes($c->price)."',
  service_discount:'".addslashes($c->discount)."', main:'".addslashes($c->main_commission)."', assist:'".addslashes($c->assist_commission)."'};\n";

}
?>
                        </select>
                      </div>
                      <input
                          type="hidden" 
                        name="transaction_no" value="<?= $id; ?>"
                        />
                        <input
                          type="hidden" 
                        name="jenis" value="<?= $jenis; ?>"
                        />
                        <input
                          type="text" 
                          style="display:none;" name="item_service" id="service" readonly
                        />
                     
                        <div class="mb-3">
                        <label for="disabledTextInput1">Price</label>
                        <input
                          type="text" 
                          class="form-control" class="form-control" name="price" id="service_price" readonly
                        />
</div>
                     
                        <input
                          type="text" 
                          class="form-control" style="display:none;" name="discount" id="service_discount" readonly
                        />
                     
                    
                        <input
                          type="text" 
                          class="form-control"  style="display:none;" name="main_commission" id="main" readonly
                        />
                      
                    
                        <input
                          type="text" 
                          class="form-control"  style="display:none;" name="assist_commission" id="assist" readonly
                        />
                      <div class="mb-3">
                        <label for="disabledTextInput1">Qty</label>
                        <input
                          type="text" 
                          class="form-control"  name="qty" value="1"
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Work Date</label>
                        <input
                          type="date" 
                          class="form-control"  name="work_date" value="<?= date('Y-m-d'); ?>"
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Main Therapist</label>
                       <select
                    class="select2 form-control custom-select"
                    style="width: 100%; height: 36px" name="main_therapist"
                  >
                  <option value="0">Choose</option>
                  <?php foreach ($dt_beautycian as $p):?>
<option value="<?= $p->id_beautycian; ?>"><?= $p->name; ?></option>
                  <?php endforeach; ?>

                </select>
                      </div>

                      <div class="mb-3">
                        <label for="disabledTextInput1">Assist</label>
                       <select
                    class="select2 form-control custom-select"
                    style="width: 100%; height: 36px" name="assist_therapist"
                  >
<option value="0">Choose</option>
                  <?php foreach ($dt_beautycian as $q):?>
<option value="<?= $q->id_beautycian; ?>"><?= $q->name; ?></option>
                  <?php endforeach; ?>

                </select>
                      </div>
                     
                     
                     
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>




            <div
                        class="modal fade"
                        id="bs-item"
                        tabindex=""
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Add Item
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                            <form name="myFormm" action="<?= base_url('app/add_detail_item_transaction'); ?>" onsubmit="return validateFormm()" method="post">
                    <div class="mb-3">
                        <label for="disabledTextInput1">Item</label>
                        <select class="select2 form-control custom-select"
                    style="width: 100%; height: 36px" name="id_item_list"  onchange="changeValuee(this.value)">
                    <option>Pilih</option>
                      
                          <?php

$jsArrayy = "var prdNamee = new Array();\n";
foreach ($dt_item as $b) {

echo '<option   value="' . $b->id_item_list. '">' . $b->item_name .  '</option>';  
$jsArrayy .= "prdNamee['" . $b->id_item_list . "'] = {opt_nama:'" . addslashes($b->item_name) . "',opt_price:'".addslashes($b->item_price)."',
  opt_discount:'".addslashes($b->discount_item)."',opt_stock:'".addslashes($b->item_qty)."'};\n";

}
?>
                        </select>
                      </div>
                      <input
                          type="hidden" 
                        name="transaction_no" value="<?= $id; ?>"
                        />
                        <input
                          type="hidden" 
                        name="jenis" value="<?= $jenis; ?>"
                        />
                        <input
                          type="text" 
                          class="form-control" style="display:none;" name="item_service" id="opt_nama" readonly
                        />
                        <div class="mb-3">
                        <label for="disabledTextInput1">Stock</label>
                        <input
                          type="text" 
                          class="form-control" id="opt_stock" name="stock" 
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Price</label>
                        <input
                          type="text" 
                          class="form-control" name="price" id="opt_price" readonly
                        />
                      </div>

                      <div class="mb-3">
                        <label for="disabledTextInput1">Item Date</label>
                        <input
                          type="date" 
                          class="form-control"  name="work_date" value="<?= date('Y-m-d'); ?>"
                        />
                      </div>
                     
                        <input
                          type="text" 
                          class="form-control" style="display:none;" name="discount" id="opt_discount" readonly
                        />
                      
                      <div class="mb-3">
                        <label for="disabledTextInput1">Qty</label>
                        <input
                          type="number" 
                          class="form-control" name="qty" required
                        />
                      </div>
                     
                     
                     
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>


                    <div
                        class="modal fade"
                        id="bs-package"
                        tabindex=""
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Add Service package
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">

    <form name="myFormmm" action="<?= base_url('app/add_detail_package_transaction'); ?>" onsubmit="return validateFormmm()" method="post">
                    <div class="mb-3">
                        <label for="disabledTextInput1">Service Package</label>
                        <select class="select2 form-control custom-select"
                    style="width: 100%; height: 36px" name="id_service_package"  onchange="changeValueee(this.value)">
                    <option>Pilih</option>
                      
                          <?php

$jsArrayyy = "var prdNameee= new Array();\n";
foreach ($dt_service_package as $e) {

echo '<option   value="' . $e->id_service_package . '">' . $e->package_name . '</option>';  
$jsArrayyy .= "prdNameee['" . $e->id_service_package . "'] = {package:'" . addslashes($e->package_name) . "',
   main_package:'".addslashes($e->main_commission)."', assist_package:'".addslashes($e->assist_commission)."'};\n";

}
?>
                        </select>
                      </div>
                      <input
                          type="hidden" 
                        name="transaction_no" value="<?= $id; ?>"
                        />
                        <input
                          type="hidden" 
                        name="jenis" value="<?= $jenis; ?>"
                        />
                        <input
                          type="text" 
                          style="display:none;" name="item_service" id="package" readonly
                        />
                     
                     

                     
                     
                     
                      
                        <input
                          type="text" 
                          class="form-control" style="display:none;" name="main_commission" id="main_package" readonly
                        />
                    
                        <input
                          type="text" 
                          class="form-control" name="assist_commission" style="display:none;" id="assist_package" readonly
                        />
                     
                      <div class="mb-3">
                        <label for="disabledTextInput1">Work Date</label>
                        <input
                          type="date" 
                          class="form-control"  name="work_date" value="<?= date('Y-m-d'); ?>"
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Main Therapist</label>
                       <select
                    class="select2 form-control custom-select"
                    style="width: 100%; height: 36px" name="main_therapist"
                  >
                  <option value="0">Choose</option>
                  <?php foreach ($dt_beautycian as $p):?>
<option value="<?= $p->id_beautycian; ?>"><?= $p->name; ?></option>
                  <?php endforeach; ?>

                </select>
                      </div>

                      <div class="mb-3">
                        <label for="disabledTextInput1">Assist</label>
                       <select
                    class="select2 form-control custom-select"
                    style="width: 100%; height: 36px" name="assist_therapist"
                  >
<option value="0">Choose</option>
                  <?php foreach ($dt_beautycian as $q):?>
<option value="<?= $q->id_beautycian; ?>"><?= $q->name; ?></option>
                  <?php endforeach; ?>

                </select>
                      </div>
                     
                     
                     
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>

                    <script type="text/javascript"> 
<?php echo $jsArrayy; ?>
function changeValuee(id){
    document.getElementById('opt_nama').value = prdNamee[id].opt_nama;
    document.getElementById('opt_price').value = prdNamee[id].opt_price;
    document.getElementById('opt_discount').value = prdNamee[id].opt_discount;
    document.getElementById('opt_stock').value = prdNamee[id].opt_stock;

};
</script>

<script type="text/javascript"> 
<?php echo $jsArray; ?>
function changeValue(id){
    document.getElementById('service').value = prdName[id].service;
    document.getElementById('service_price').value = prdName[id].service_price;
    document.getElementById('service_discount').value = prdName[id].service_discount;
    document.getElementById('main').value = prdName[id].main;
    document.getElementById('assist').value = prdName[id].assist;

};
</script>
<script type="text/javascript"> 
<?php echo $jsArrayyy; ?>
function changeValueee(id){
    document.getElementById('package').value = prdNameee[id].package;
    document.getElementById('main_package').value = prdNameee[id].main_package;
    document.getElementById('assist_package').value = prdNameee[id].assist_package;

};
</script>
<script>
function validateFormed() {
  let a = document.forms["myFormed"]["assist_commissioned"].value;
  let b = document.forms["myFormed"]["assist_therapisted"].value;
  let c = document.forms["myFormed"]["main_commissioned"].value;
  let d = document.forms["myFormed"]["main_therapisted"].value;
  if ( a !=0 ) {
    if ( b ==0 ) {
    alert("asist therapist must be filled");
    return false;
    }
  }
  if ( c !=0 ) {
    if ( d ==0 ) {
    alert("main therapist must be filled");
    return false;
    }
  }


  if ( a ==0 ) {
    if ( b !=0 ) {
    alert("asist therapist cannot be filled");
    return false;
    }
  }
  if ( c ==0 ) {
    if ( d !=0 ) {
    alert("main therapist cannot be filled");
    return false;
    }
  }

}
</script>
<script>
function validateForm() {
  let a = document.forms["myForm"]["assist_commission"].value;
  let b = document.forms["myForm"]["assist_therapist"].value;
  let c = document.forms["myForm"]["main_commission"].value;
  let d = document.forms["myForm"]["main_therapist"].value;
  if ( a !=0 ) {
    if ( b ==0 ) {
    alert("asist therapist must be filled");
    return false;
    }
  }
  if ( c !=0 ) {
    if ( d ==0 ) {
    alert("main therapist must be filled");
    return false;
    }
  }


  if ( a ==0 ) {
    if ( b !=0 ) {
    alert("asist therapist cannot be filled");
    return false;
    }
  }
  if ( c ==0 ) {
    if ( d !=0 ) {
    alert("main therapist cannot be filled");
    return false;
    }
  }

}
</script>

<script>
function validateFormmm() {
  let a = document.forms["myFormmm"]["assist_commission"].value;
  let b = document.forms["myFormmm"]["assist_therapist"].value;
  let c = document.forms["myFormmm"]["main_commission"].value;
  let d = document.forms["myFormmm"]["main_therapist"].value;
  if ( a !=0 ) {
    if ( b ==0 ) {
    alert("asist therapist must be filled");
    return false;
    }
  }
  if ( c !=0 ) {
    if ( d ==0 ) {
    alert("main therapist must be filled");
    return false;
    }
  }


  if ( a ==0 ) {
    if ( b !=0 ) {
    alert("asist therapist cannot be filled");
    return false;
    }
  }
  if ( c ==0 ) {
    if ( d !=0 ) {
    alert("main therapist cannot be filled");
    return false;
    }
  }

}
</script>
<script>
function validateFormm() {

  var qty=document.myFormm.qty.value;  
  var stock=document.myFormm.stock.value; 
 
    if ( qty>stock ) {
    alert("stok tidak mencukupi");
    return false;
    
  }
  

}
</script>