      <?php 

function rupiah($angka){
  
  $hasil_rupiah = "" . number_format($angka,0,',','.');
  return $hasil_rupiah;

}
?>

   <div class="page-breadcrumb">
          <div class="row">
            <div class="col-md-5 align-self-center">
              <h3 class="page-title">Dashboard</h3>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                     <?= $judul; ?>
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
            <div
              class="
                col-md-7
                justify-content-end
                align-self-center
                d-none d-md-flex
              "
            >
             
            </div>
          </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
<div class="row">
            <div class="col-12">
              <div class="card">
                <div class="border-bottom title-part-padding">
                  <h4 class="card-title mb-0"></h4>
                </div>
                <div class="card-body">
                  
                  <div class="table-responsive">
                    <table
                      id="zero_config"
                      class="table table-striped table-bordered"
                    >
                      <thead>
                        <tr>
                          <th>No</th>
                          <th>Item Name</th>
                          <th>Description</th>
                          <th>Price (IDR)</th>
                          <th>Discount</th>
                          <th>Qty</th>
                          <th>Unit</th>
                         
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $no=1; ?>
                  <?php foreach($dt_item_list as $d): ?>
                        <tr>
                          <td><?= $no++; ?></td>
                          <td><?= $d->item_name; ?></td>
                          <td><?= $d->item_description; ?></td>
                          <td><?= rupiah($d->item_price); ?></td>
                          <td><?= $d->discount_item; ?> %</td>
                          <td><?= $d->item_qty; ?></td>
                          <td><?= $d->item_unit; ?></td>
                         
                          <td>
                       <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Delete" onclick="return confirm('Do you really want to delete ?')" href="<?php echo base_url('app/delete_item_list/'.$d->id_item_list);?>" class="btn btn-danger btn-xs" ><i class="fa fa-trash"></i></a>  
                        <a data-tooltip="tooltip"
                      data-bs-placement="top"
                      title="Update" data-bs-toggle="modal"
                        data-bs-target="#edit<?= $d->id_item_list; ?>"  class="btn btn-info btn-xs" ><i class="fa fa-edit"></i></a>  
                      </td>
                        </tr>
  <div
                        class="modal fade"
                        id="edit<?= $d->id_item_list; ?>"
                        tabindex="-1"
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Update Item List
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/update_item_list'); ?>
                  <?php
                                                        $id=$d->id_item_list;
                                                        $query=$this->db->query("Select * from item_list where id_item_list='$id'");
                                                        foreach ($query->result() as $a) :?>
                                                           <div class="mb-3">
                      
                        <input
                          type="hidden"
                          class="form-control" name="id_item_list" value="<?= $a->id_item_list; ?>" required
                        />
                      
                      </div>
                      <div class="mb-3">
                         
                        <label for="disabledTextInput1">Item Description</label>
                        <input
                          type="text"
                          class="form-control" name="item_description" value="<?= $a->item_description; ?>" required
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Item Price</label>
                        <input
                          type="text"
                          class="form-control" name="item_price" value="<?= $a->item_price; ?>" required
                        />
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Discount</label>
                        <input
                          type="number"
                          class="form-control" name="discount_item" value="<?= $a->discount_item; ?>" required
                        />
                      </div>
               
                      
                       
                       
                     <?php endforeach; ?>
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Update"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>

                      <?php endforeach; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>





            <div
                        class="modal fade"
                        id="bs-example-modal-lg"
                        tabindex=""
                        aria-labelledby="bs-example-modal-lg"
                        aria-hidden="true"
                      >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header d-flex align-items-center">
                              <h4 class="modal-title" id="myLargeModalLabel">
                               Add item_list
                              </h4>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <?php echo validation_errors();
    echo form_open('app/add_item_list'); ?>
                    <div class="mb-3">
                        <label for="disabledTextInput1">item Name</label>
                       <select
                    class="select2 form-control custom-select"
                    style="width: 100%; height: 36px" name="id_item_name"
                  >

                  <?php foreach ($dt_item_name as $a):?>
<option value="<?= $a->id_item_name; ?>"><?= $a->item_name; ?></option>
                  <?php endforeach; ?>

                </select>
                      </div>
                      <div class="mb-3">
                        <label for="disabledTextInput1">Item Description</label>
                        <input
                          type="text"
                          class="form-control" name="item_description" required
                        />
                      </div>
                     
                       <div class="mb-3">
                        <label for="disabledTextInput1">Item Price</label>
                        <input
                          type="text"
                          class="form-control" name="item_price" required
                        />
                      </div>
                 <div class="mb-3">
                        <label for="disabledTextInput1">Item Qty</label>
                        <input
                          type="number"
                          class="form-control" name="item_qty" required
                        />
                      </div>
                       <div class="mb-3">
                        <label for="disabledTextInput1">Unit</label>
                        <select
                    class="select" name="unit"
                  >

                  <?php foreach ($dt_satuan as $g):?>
<option value="<?= $g->id_satuan; ?>"><?= $g->nama_satuan; ?></option>
                  <?php endforeach; ?>

                </select>
                      </div>
                      
                     
                  
                            </div>
                            <div class="modal-footer">
                              <button
                                type="button"
                                class="
                                  btn btn-danger
                                
                                "
                                data-bs-dismiss="modal"
                              >
                                Close
                              </button>
                              <input
                                type="submit"
                                name="submit"
                                class="
                                  btn btn-info
                                
                                "
                               value="Submit"
                              >
                               
                            
                              </form>
                            </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                    </div>
                    <div>