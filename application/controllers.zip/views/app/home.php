<?php 

function rupiah($angka){
  
  $hasil_rupiah = "" . number_format($angka,2,',','.');
  return $hasil_rupiah;

}
?>
   <div class="page-breadcrumb">
          <div class="row">
            <div class="col-md-5 align-self-center">
              <h3 class="page-title">Dashboard</h3>
              <div class="d-flex align-items-center">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                      Dashboard
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
            <div
              class="
                col-md-7
                justify-content-end
                align-self-center
                d-none d-md-flex
              "
            >
             
            </div>
          </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">

        <?php  if($this->session->userdata('akses')=='2' ) :?>
  <div class="row">
            <!-- Column -->
            

            <div class="col-md-12 col-lg-12 col-xlg-3">
              <div class="card">
                <div class="box p-2 rounded bg-light text-center">
                  <h3 class="fw-light text-black"><?php

$date=date('Y-m-d');
$query=$this->db->query("Select sum(nominal) as today from payment where date_payment='$date'");
 foreach ($query->result() as $t) :?>
<?= rupiah($t->today); ?>
 <?php endforeach; ?></h3>
                  <h6 class="text-black">Todays Income</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <!-- Column -->
 </div>
 <?php endif; ?>
        <?php  if($this->session->userdata('akses')=='1' ) :?>
  <div class="row">
            <!-- Column -->
            

            <div class="col-md-6 col-lg-4 col-xlg-3">
              <div class="card">
                <div class="box p-2 rounded bg-light text-center">
                  <h3 class="fw-light text-black"><?php

$date=date('Y-m-d');
$query=$this->db->query("Select sum(nominal) as today from payment where date_payment='$date'");
 foreach ($query->result() as $t) :?>
<?= rupiah($t->today); ?>
 <?php endforeach; ?></h3>
                  <h6 class="text-black">Todays Income</h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <!-- Column -->
          

            <div class="col-md-6 col-lg-4 col-xlg-3">
              <div class="card">
                <div class="box p-2 rounded bg-light text-center">
                  <h3 class="fw-light text-black"><?php

$m=date('m');
$y=date('Y');
$monthly=$this->db->query("Select sum(nominal) as monthly from payment where month(date_payment)=$m and year(date_payment)=$y");
 foreach ($monthly->result() as $mt) :?>
<?= rupiah($mt->monthly); ?>
 <?php endforeach; ?></h3>
                  <h6 class="text-black">Monthly Income </h6>
                </div>
              </div>
            </div>

          

            
            <div class="col-md-6 col-lg-4 col-xlg-3">
              <div class="card">
                <div class="box p-2 rounded bg-light text-center">
                  <h3 class="fw-light text-black"> <?php

$year=$this->db->query("Select sum(nominal) as year from payment where  year(date_payment)=$y");
 foreach ($year->result() as $yr) :?>
<?= rupiah($yr->year); ?>
 <?php endforeach; ?></h3>
                  <h6 class="text-black">Year Income </h6>
                </div>
              </div>
            </div>
            <!-- Column -->
            <!-- Column -->
          
            <!-- Column -->
            <?php endif; ?>
           <?php  if($this->session->userdata('akses')=='1' ) :?>
            <div class="col-lg-12">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header bg-success py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-white">Transactions Graph in  <?= date('Y'); ?></h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">
                <div class="chart-area">
                    <div class="chartjs-size-monitor">
                        <div class="chartjs-size-monitor-expand">
                            <div class=""></div>
                        </div>
                        <div class="chartjs-size-monitor-shrink">
                            <div class=""></div>
                        </div>
                    </div>
                    <div id="chart">
</div>
                </div>
            </div>
        </div>
    </div>
          </div>

          <?php endif; ?>