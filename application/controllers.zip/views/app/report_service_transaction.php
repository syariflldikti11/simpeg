<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=report service transaction.xls");
?>
<?php 

function rupiah($angka){
  
  $hasil_rupiah = "" . number_format($angka,0,',','.');
  return $hasil_rupiah;

}
?>

<?php
function formatTanggal($date){
    // ubah string menjadi format tanggal
    return date('d-m-Y', strtotime($date));
   }
   
$dari=$_POST['dari'];
$sampai=$_POST['sampai'];
?>
<center><?= formatTanggal($dari); ?> s/d <?= formatTanggal($sampai); ?></center>
<br />
<table border="1">
    <tr>
                          <th>No</th>
                          <th>Transaction No</th>
                        <th>Patient</th>
                          <th>Work Date</th>
                          <th>Service</th>
                          <th>Main Therapist</th>
                          <th>Asist Therapist</th>
                    
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                      $no=1;
                     $query=$this->db->query("Select * from detail_transaction a join transaction b
                     on a.transaction_no=b.transaction_no  join patient c on b.id_patient=c.id_patient 
                     where a.work_date between '$dari' and '$sampai'");
                        foreach ($query->result() as $d) :?>
                                                      
                                                  
                        <tr>
                          <td><?= $no++; ?></td>
                          <td><?= $d->transaction_no; ?></td>
                          <td><?= $d->patient_name; ?></td>
                          <td><?= $d->work_date; ?></td>
                          <td><?= $d->item_service; ?></td>
                         <td>  <?php
                                                        $id=$d->id_detail_transaction;
                                                        $query=$this->db->query("Select * from main_commission a join beautycian b on a.id_beautycian=b.id_beautycian where id_detail_transaction='$id'");
                                                        foreach ($query->result() as $m) :?>
                                                        <?= $m->name; ?>
                                                    <?php endforeach; ?></td>
                          
                            <td> <?php
                                                        
                                                        $assist=$this->db->query("Select * from assist_commission a join beautycian b on a.id_beautycian=b.id_beautycian where id_detail_transaction='$id'");
                                                        foreach ($assist->result() as $n) :?>
                                                          <?= $n->name; ?>
                                                    <?php endforeach; ?>
                                                </td>
                  </tr>
                  <?php endforeach; ?>
                  </table>

                  <?php
        exit ()
        ?>