<?php

class App extends CI_Controller {
	function __construct(){
    parent::__construct();
    $this->load->database();
   
    //validasi jika user belum login
    if($this->session->userdata('masuk') != TRUE){
            $url=base_url();
            redirect($url);
        }
  }

  public function ajax_list()
  {
      
      $list = $this->umum->get_datatables();
      $data = array();
      $no = $this->input->post('start');
      //looping data mahasiswa
      foreach ($list as $d) {
          $no++;
          $row = array();
          //row pertama akan kita gunakan untuk btn edit dan delete
          $row[] =  $no;
        
          $row[]= $d->patient_number; 
          $row[]= $d->patient_name; 
          $row[]= $d->patient_gender; 
          $row[]= $d->patient_pob; 
          $row[]= $d->patient_address; 
          
          $row[] =  ' <a data-tooltip="tooltip"
          data-bs-placement="top"
          title="Medical Records"  href="'.base_url('app/report_medical_record').'/'.$d->id_patient.'"
            class="btn btn-primary btn-xs" ><i class="fa fa-stethoscope"></i></a> ';
         $data[] = $row;
      }
      $output = array(
          "draw" => $this->input->post('draw'),
          "recordsTotal" => $this->umum->count_all(),
          "recordsFiltered" => $this->umum->count_filtered(),
          "data" => $data,
      );
      //output to json format
      echo json_encode($output);
  }
   public function ajax_list_admin()
  {
      
      $list = $this->umum->get_datatables();
      $data = array();
      $no = $this->input->post('start');
      //looping data mahasiswa
      foreach ($list as $d) {
          $no++;
          $row = array();
          //row pertama akan kita gunakan untuk btn edit dan delete
          $row[] =  $no;
        
          $row[]= $d->patient_number; 
          $row[]= $d->patient_name; 
          $row[]= $d->patient_gender; 
          $row[]= $d->patient_pob; 
          $row[]= $d->patient_address; 
          $row[]= $d->patient_phone; 
          $row[] =  ' <a data-tooltip="tooltip"
          data-bs-placement="top"
          title="Delete" onclick="return confirm(\'Do you really want to delete ?\')"  href="'.base_url('app/delete_patient').'/'.$d->id_patient.'" 
          class="btn btn-danger btn-xs" ><i class="fa fa-trash"></i></a>  <a data-tooltip="tooltip"
          data-bs-placement="top"
          title="Medical Records"  href="'.base_url('app/report_medical_record').'/'.$d->id_patient.'"
            class="btn btn-primary btn-xs" ><i class="fa fa-stethoscope"></i></a> ';
         $data[] = $row;
      }
      $output = array(
          "draw" => $this->input->post('draw'),
          "recordsTotal" => $this->umum->count_all(),
          "recordsFiltered" => $this->umum->count_filtered(),
          "data" => $data,
      );
      //output to json format
      echo json_encode($output);
  }

public function index()
    {
        if($this->session->userdata('akses')<'3' ) {
         $data['judul'] = "Dashboard";
        foreach($this->umum->grafik_penjualan()->result_array() as $row)
        {
         $data['grafik_penjualan'][]=(float)$row['Januari'];
         $data['grafik_penjualan'][]=(float)$row['Februari'];
         $data['grafik_penjualan'][]=(float)$row['Maret'];
         $data['grafik_penjualan'][]=(float)$row['April'];
         $data['grafik_penjualan'][]=(float)$row['Mei'];
         $data['grafik_penjualan'][]=(float)$row['Juni'];
         $data['grafik_penjualan'][]=(float)$row['Juli'];
         $data['grafik_penjualan'][]=(float)$row['Agustus'];
         $data['grafik_penjualan'][]=(float)$row['September'];
         $data['grafik_penjualan'][]=(float)$row['Oktober'];
         $data['grafik_penjualan'][]=(float)$row['November'];
         $data['grafik_penjualan'][]=(float)$row['Desember'];
        }
     
        foreach($this->umum->grafik_service()->result_array() as $roww)
        {
         $data['grafik_service'][]=(float)$roww['Januari'];
         $data['grafik_service'][]=(float)$roww['Februari'];
         $data['grafik_service'][]=(float)$roww['Maret'];
         $data['grafik_service'][]=(float)$roww['April'];
         $data['grafik_service'][]=(float)$roww['Mei'];
         $data['grafik_service'][]=(float)$roww['Juni'];
         $data['grafik_service'][]=(float)$roww['Juli'];
         $data['grafik_service'][]=(float)$roww['Agustus'];
         $data['grafik_service'][]=(float)$roww['September'];
         $data['grafik_service'][]=(float)$roww['Oktober'];
         $data['grafik_service'][]=(float)$roww['November'];
         $data['grafik_service'][]=(float)$roww['Desember'];
        }
        foreach($this->umum->grafik_service_package()->result_array() as $rowww)
        {
         $data['grafik_service_package'][]=(float)$rowww['Januari'];
         $data['grafik_service_package'][]=(float)$rowww['Februari'];
         $data['grafik_service_package'][]=(float)$rowww['Maret'];
         $data['grafik_service_package'][]=(float)$rowww['April'];
         $data['grafik_service_package'][]=(float)$rowww['Mei'];
         $data['grafik_service_package'][]=(float)$rowww['Juni'];
         $data['grafik_service_package'][]=(float)$rowww['Juli'];
         $data['grafik_service_package'][]=(float)$rowww['Agustus'];
         $data['grafik_service_package'][]=(float)$rowww['September'];
         $data['grafik_service_package'][]=(float)$rowww['Oktober'];
         $data['grafik_service_package'][]=(float)$rowww['November'];
         $data['grafik_service_package'][]=(float)$rowww['Desember'];
        }
             
        $this->template->load('app/template', 'app/home', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
function report_service_transaction()
{
    $dari=$this->input->post('dari');
    $sampai=$this->input->post('sampai');
    $this->load->view('app/report_service_transaction');
}
function report_item_transaction()
{
    $dari=$this->input->post('dari');
    $sampai=$this->input->post('sampai');
    $this->load->view('app/report_item_transaction');
}
function report_salary()
{
    $dari=$this->input->post('dari');
    $id_beautycian=$this->input->post('id_beautycian');
    $sampai=$this->input->post('sampai');
    $this->load->view('app/report_salary');
}
function medical_record()
{
    $id_detail_transaction=$this->input->post('id_detail_transaction');
    $medical_record=$this->input->post('medical_record');
    $data = array(
        'medical_record' => $medical_record
        );
        $this->db->set($data);
        $this->db->where('id_detail_transaction', $id_detail_transaction);
        $this->db->update('detail_transaction');
             $notif = " Success add Medical Record";
                    $this->session->set_flashdata('success', $notif);
                    redirect('app/therapist_schedule');
}
public function report_medical_record($id)
{
    
    $data = array(
        'id_patient'=>$id,
        'dt_medical_record' => $this->umum->get_medical_record($id),
       
    );
    $this->load->view('app/report_medical_record', $data);

}
public function print_payment($id_payment,$id)
{
    
    $data = array(
        'dt_transaction' => $this->umum->get_detail_transaction($id),
        'id_payment'=> $id_payment,
    );
    $this->load->view('app/print_payment', $data);

}
function finished($id)
{
    $data = array(
        'status' => 1
        );
        $this->db->set($data);
        $this->db->where('id_detail_transaction', $id);
        $this->db->update('detail_transaction');
             $notif = " Finished";
                    $this->session->set_flashdata('success', $notif);
                    redirect('app/therapist_schedule');
}

public function item_name()
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'item Name Data',
            'dt_item_name' => $this->umum->get_data('item_name'),
        );
        $this->template->load('app/template', 'app/item_name', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
function add_item_name()
    {
        $this->db->set('id_item_name','UUID()',false);
        $this->form_validation->set_rules('item_name','item_name','required');
        if($this->form_validation->run() === FALSE)
            redirect('app/item_name');
        else

            $this->umum->set_data("item_name");
             $notif = "Success Add Data";
            $this->session->set_flashdata('success', $notif);
            redirect('app/item_name');
        }
    

    function delete_item_name($id=NULL)
    {
        $this->umum->hapus('item_name','id_item_name',$id);
         $notif = "Success Delete Data";
            $this->session->set_flashdata('delete', $notif);
        redirect('app/item_name');
    }
    function update_item_name()
    {
        $this->form_validation->set_rules('id_item_name','id_item_name','required');
        if($this->form_validation->run() === FALSE)
             redirect('app/item_name');
        else
        {
            $this->umum->update_data("item_name");
             $notif = " Success Update Data";
            $this->session->set_flashdata('update', $notif);
            redirect('app/item_name');
        }
    }
    public function item_unit()
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'item Name Data',
            'dt_item_unit' => $this->umum->get_data('item_unit'),
        );
        $this->template->load('app/template', 'app/item_unit', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
function add_item_unit()
    {
        $this->db->set('id_item_unit','UUID()',false);
        $this->form_validation->set_rules('item_unit','item_unit','required');
        if($this->form_validation->run() === FALSE)
            redirect('app/item_unit');
        else

            $this->umum->set_data("item_unit");
             $notif = "Success Add Data";
            $this->session->set_flashdata('success', $notif);
            redirect('app/item_unit');
        }
    

    function delete_item_unit($id=NULL)
    {
        $this->umum->hapus('item_unit','id_item_unit',$id);
         $notif = "Success Delete Data";
            $this->session->set_flashdata('delete', $notif);
        redirect('app/item_unit');
    }
    function update_item_unit()
    {
        $this->form_validation->set_rules('id_item_unit','id_item_unit','required');
        if($this->form_validation->run() === FALSE)
             redirect('app/item_unit');
        else
        {
            $this->umum->update_data("item_unit");
             $notif = " Success Update Data";
            $this->session->set_flashdata('update', $notif);
            redirect('app/item_unit');
        }
    }
    public function item_list()
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'item List Data',
            'dt_item_list' => $this->umum->get_item_list(),
            'dt_item_name' => $this->umum->get_item_name(),
            'dt_item_unit' => $this->umum->get_data('item_unit'),
        );
        $this->template->load('app/template', 'app/item_list', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
function add_item_list()
    {
        $this->db->set('id_item_list','UUID()',false);
        $this->form_validation->set_rules('id_item_name','id_item_name','required');
        if($this->form_validation->run() === FALSE)
            redirect('app/item_list');
        else

            $this->umum->set_data("item_list");
             $notif = "Success Add Data";
            $this->session->set_flashdata('success', $notif);
            redirect('app/item_list');
        }
    

    function delete_item_list($id=NULL)
    {
        $this->umum->hapus('item_list','id_item_list',$id);
         $notif = "Success Delete Data";
            $this->session->set_flashdata('delete', $notif);
        redirect('app/item_list');
    }
    function update_item_list()
    {
        $this->form_validation->set_rules('id_item_list','id_item_list','required');
        if($this->form_validation->run() === FALSE)
             redirect('app/item_list');
        else
        {
            $this->umum->update_data("item_list");
             $notif = " Success Update Data";
            $this->session->set_flashdata('update', $notif);
            redirect('app/item_list');
        }
    }
     public function incoming_item()
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'Incoming Item Data',
            'dt_incoming_item' => $this->umum->get_incoming_item(),
            'dt_item_name' => $this->umum->get_item_name(),
            'dt_item_unit' => $this->umum->get_data('item_unit'),
            
        );
        $this->template->load('app/template', 'app/incoming_item', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
function add_incoming_item(){
    $id_item_name=$this->input->post('id_item_name');
    $item_description = $this->input->post('item_description');
    $item_price = $this->input->post('item_price');
    $item_qty = $this->input->post('item_qty');
    $unit = $this->input->post('unit');
    $date=date('Y-m-d');
     $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 40);
    $incoming_item = array(       
            'id_incoming_item' => $kode_unik,
            'id_item_name' => $id_item_name,
            'item_description' => $item_description,
            'item_price' => $item_price,
            'item_qty' => $item_qty,
            'unit' => $unit,
            'tgl_input' => $date,
            );
             $item_list = array(
            'id_item_list' => $kode_unik,
            'id_item_name' => $id_item_name,
            'item_description' => $item_description,
            'item_price' => $item_price,
            'item_qty' => $item_qty,
            'unit' => $unit
            );
           $this->db->select('*');
       $this->db->from('item_list');
       $this->db->where('id_item_name= "'.$id_item_name.'" and unit= "'.$unit.'" ');
   $query = $this->db->get();
   if($query->num_rows()>0)
   {
 $notif = " Data  berhasil ditambahkan";
            $this->session->set_flashdata('success', $notif);
 $this->umum->input_data($incoming_item,'incoming_item');
 redirect('app/incoming_item');
   }  
   else {
 $this->umum->input_data($incoming_item,'incoming_item');
 $this->umum->input_data($item_list,'item_list');
 $notif = " Data berhasil ditambahkan";
            $this->session->set_flashdata('success', $notif);
    redirect('app/incoming_item');
}
    }
    

    function delete_incoming_item($id=NULL)
    {
        $this->umum->hapus('incoming_item','id_incoming_item',$id);
         $notif = "Success Delete Data";
            $this->session->set_flashdata('delete', $notif);
        redirect('app/incoming_item');
    }
    function update_incoming_item()
    {
        $this->form_validation->set_rules('id_incoming_item','id_incoming_item','required');
        if($this->form_validation->run() === FALSE)
             redirect('app/incoming_item');
        else
        {
            $this->umum->update_data("incoming_item");
             $notif = " Success Update Data";
            $this->session->set_flashdata('update', $notif);
            redirect('app/incoming_item');
        }
    }
public function service()
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'Service Data',
            'dt_service' => $this->umum->get_data('service'),
        );
        $this->template->load('app/template', 'app/service', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
function add_service()
    {
        $this->db->set('id_service','UUID()',false);
        $this->form_validation->set_rules('service_name','service_name','required');
        if($this->form_validation->run() === FALSE)
            redirect('app/service');
        else

            $this->umum->set_data("service");
             $notif = "Success Add Data";
            $this->session->set_flashdata('success', $notif);
            redirect('app/service');
        }
    

    function delete_service($id=NULL)
    {
        $this->umum->hapus('service','id_service',$id);
         $notif = "Success Delete Data";
            $this->session->set_flashdata('delete', $notif);
        redirect('app/service');
    }
    function update_service()
    {
        $this->form_validation->set_rules('id_service','id_service','required');
        if($this->form_validation->run() === FALSE)
             redirect('app/service');
        else
        {
            $this->umum->update_data("service");
             $notif = " Success Update Data";
            $this->session->set_flashdata('update', $notif);
            redirect('app/service');
        }
    }
    public function service_package()
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'Service Package Data',
            'dt_service_package' => $this->umum->get_data('service_package'),
        );
        $this->template->load('app/template', 'app/service_package', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
function add_service_package()
    {
        $this->db->set('id_service_package','UUID()',false);
        $this->form_validation->set_rules('package_name','package_name','required');
        if($this->form_validation->run() === FALSE)
            redirect('app/service_package');
        else

            $this->umum->set_data("service_package");
             $notif = "Success Add Data";
            $this->session->set_flashdata('success', $notif);
            redirect('app/service_package');
        }
    

    function delete_service_package($id=NULL)
    {
        $this->umum->hapus('service_package','id_service_package',$id);
         $notif = "Success Delete Data";
            $this->session->set_flashdata('delete', $notif);
        redirect('app/service_package');
    }
    function update_service_package()
    {
        $this->form_validation->set_rules('id_service_package','id_service_package','required');
        if($this->form_validation->run() === FALSE)
             redirect('app/service_package');
        else
        {
            $this->umum->update_data("service_package");
             $notif = " Success Update Data";
            $this->session->set_flashdata('update', $notif);
            redirect('app/service_package');
        }
    }
public function beautycian()
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'Beautycian Data',
            'dt_beautycian' => $this->umum->get_data('beautycian'),
        );
        $this->template->load('app/template', 'app/beautycian', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
 function add_beautycian()
    {
        $this->db->set('id_beautycian','UUID()',false);
        $this->form_validation->set_rules('name','name','required');
        if($this->form_validation->run() === FALSE)
        redirect('app/beautycian');
        else

            $this->umum->set_data("beautycian");
             $notif = "Success Add Data";
            $this->session->set_flashdata('success', $notif);
            redirect('app/beautycian');
        }
    

    function delete_beautycian($id=NULL)
    {
        $this->umum->hapus('beautycian','id_beautycian',$id);
         $notif = "Success Delete Data";
            $this->session->set_flashdata('delete', $notif);
        redirect('app/beautycian');
    }
    function update_beautycian()
    {
        $this->form_validation->set_rules('id_beautycian','id_beautycian','required');
        if($this->form_validation->run() === FALSE)
            redirect('app/beautycian');
        else
        {
            $this->umum->update_data("beautycian");
             $notif = " Success Update Data";
            $this->session->set_flashdata('update', $notif);
            redirect('app/beautycian');
        }
    }
    public function patient()
    {
        
        $data = array(
            'judul' => 'patient Data',
            'dt_patient' => $this->umum->get_data('patient'),
        );
        if($this->session->userdata('akses')=='2') {
        $this->template->load('app/template', 'app/patient_cashier', $data);
    }

        else { 
          $this->template->load('app/template', 'app/patient', $data);
    }
}
 function add_patient()
    {
        $this->db->set('id_patient','UUID()',false);
        $this->form_validation->set_rules('patient_name','patient_name','required');
        if($this->form_validation->run() === FALSE)
            redirect('app/patient');
        else

            $this->umum->set_data("patient");
             $notif = "Success Add Data";
            $this->session->set_flashdata('success', $notif);
            redirect('app/patient');
        }
    

    function delete_patient($id=NULL)
    {
        $this->umum->hapus('patient','id_patient',$id);
         $notif = "Success Delete Data";
            $this->session->set_flashdata('delete', $notif);
        redirect('app/patient');
    }
    function update_patient()
    {
        $this->form_validation->set_rules('id_patient','id_patient','required');
        if($this->form_validation->run() === FALSE)
             redirect('app/patient');
        else
        {
            $this->umum->update_data("patient");
             $notif = " Success Update Data";
            $this->session->set_flashdata('update', $notif);
            redirect('app/patient');
        }
    }
    public function therapist_schedule()
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'Therapist Schedule',
            'dt_schedule' => $this->umum->get_therapist_schedule(),
        );
        $this->template->load('app/template', 'app/therapist_schedule', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
public function commission()
{
    if($this->session->userdata('akses')<'3') {
    $data = array(
        'judul' => 'Commission',
        'dt_schedule' => $this->umum->get_commission(),
    );
    $this->template->load('app/template', 'app/commission', $data);
}

    else {  echo "Anda tidak berhak menglevel halaman ini";
}
}
    public function payment($id,$totalp)
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'Transaction Payment',
            'id' => $id,
            'totalp' => $totalp,
            'dt_payment' => $this->umum->get_payment($id),
        );
        $this->template->load('app/template', 'app/payment', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}

    function add_payment(){
    
        $transaction_no=$this->input->post('transaction_no');
        $total = $this->input->post('total');
        $payment_date = $this->input->post('payment_date');
        $nominal = $this->input->post('nominal');
        
                $payment = array(		
                    'date_payment' => $payment_date,
                    'nominal' => $nominal,
                    'transaction_no' => $transaction_no
                    );

    
        $this->umum->input_data($payment,'payment');
        $querysum = $this->db->query("Select sum(nominal) as total from payment where transaction_no='$transaction_no'");
        foreach ($querysum->result() as $roww) {
            $total=$roww->total;
        }
      
    $data = array(
    'payment' => $total
    );
    $this->db->set($data);
    $this->db->where('transaction_no', $transaction_no);
    $this->db->update('transaction');
         $notif = " Success add data";
                $this->session->set_flashdata('success', $notif);
                redirect(base_url()."app/payment/".$transaction_no.'/'.$total);
        }
        function delete_payment($id=NULL,$transaction_no,$totalp)
        {
            $this->umum->hapus('payment','id_payment',$id);
            $querysum = $this->db->query("Select sum(nominal) as total from payment where transaction_no='$transaction_no'");
            foreach ($querysum->result() as $roww) {
                $total=$roww->total;
            }
          
        $data = array(
        'payment' => $total
        );
        $this->db->set($data);
        $this->db->where('transaction_no', $transaction_no);
        $this->db->update('transaction');
             $notif = "Success Delete Data";
                $this->session->set_flashdata('delete', $notif);
                redirect(base_url()."app/payment/".$transaction_no.'/'.$totalp);
        }
        public function package_transaction()
        {
            if($this->session->userdata('akses')<'3') {
            $data = array(
                'judul' => 'Service Package Transaction',
                'dt_package_transaction' => $this->umum->get_package_transaction(),
                'dt_service_package' => $this->umum->get_data('service_package'),
                'dt_patient' => $this->umum->get_data('patient'),
            );
            $this->template->load('app/template', 'app/package_transaction', $data);
        }
    
            else {  echo "Anda tidak berhak menglevel halaman ini";
        }
    }
    function add_package_transaction()
        {
            $date=date('dm');
            $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 6);
    $kodeunik = 'TRS-'.$kode_unik.''. $date;
            $this->db->set('id_transaction','UUID()',false);
            $this->db->set('jenis',2);
            $this->db->set('transaction_no',$kodeunik);
            $id_service_package = $this->input->post('id_service_package');
            $id_patient = $this->input->post('id_patient');
            $package = $this->input->post('package');
            $package_qty = $this->input->post('package_qty');
            $price = $this->input->post('price');
            $discount = $this->input->post('package_discount');
            $transaction_date = $this->input->post('transaction_date');
                    $data = array(		
                        'package_name' => $package,
                        'id_service_package' => $id_service_package,
                        'package_qty' => $package_qty,
                        'id_patient' => $id_patient,
                        'package_price' => $price,
                        'package_discount' => $discount,
                        'total' => $price-($price*$discount/100),
                        'transaction_date' => $transaction_date,
                        );
                      
            $this->umum->input_data($data,'transaction');
                 $notif = "Success Add Data";
                $this->session->set_flashdata('success', $notif);
                redirect('app/package_transaction');
            }
        
    
        function delete_package_transaction($id=NULL)
        {
            $this->umum->hapus('transaction','transaction_no',$id);
            $this->umum->hapus('payment','transaction_no',$id);
             $notif = "Success Delete Data";
                $this->session->set_flashdata('delete', $notif);
            redirect('app/package_transaction');
        }
    public function service_transaction()
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'Service Transaction',
            'dt_service_transaction' => $this->umum->get_service_transaction(),
            'dt_patient' => $this->umum->get_data('patient'),
        );
        $this->template->load('app/template', 'app/service_transaction', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
function add_service_transaction()
    {
        $date=date('dm');
        $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 6);
$kodeunik = 'TRS-'.$kode_unik.''. $date;
        $this->db->set('id_transaction','UUID()',false);
        $this->db->set('jenis',1);
        $this->db->set('transaction_no',$kodeunik);
        $this->form_validation->set_rules('id_patient','id_patient','required');
        if($this->form_validation->run() === FALSE)
            redirect('app/service_transaction');
        else

            $this->umum->set_data("transaction");
             $notif = "Success Add Data";
            $this->session->set_flashdata('success', $notif);
            redirect('app/service_transaction');
        }
    

    function delete_service_transaction($id=NULL)
    {
        $this->umum->hapus('transaction','transaction_no',$id);
        $this->umum->hapus('payment','transaction_no',$id);
         $notif = "Success Delete Data";
            $this->session->set_flashdata('delete', $notif);
        redirect('app/service_transaction');
    }
  
    public function detail_transaction($id,$jenis)
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => ' Detail Transaction',
            'id' => $id,
            'jenis' => $jenis,
            'dt_transaction' => $this->umum->get_detail_transaction($id),
            'dt_service' => $this->umum->get_data('service'),
            'dt_service_package' => $this->umum->get_data('service_package'),
            'dt_beautycian' => $this->umum->get_data('beautycian'),
            'dt_item' => $this->umum->get_item_list(),
        );
        $this->template->load('app/template', 'app/detail_transaction', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
function add_detail_package_transaction(){
    $item_service=$this->input->post('item_service');
    $date=date('md');
    $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 20);  
    $kodeunik = 'svd-'.$kode_unik.''. $date;
    $transaction_no=$this->input->post('transaction_no');
    $jenis = $this->input->post('jenis');
    $work_date = $this->input->post('work_date');
    $main_commission = $this->input->post('main_commission');
    $assist_commission = $this->input->post('assist_commission');
    $main_therapist = $this->input->post('main_therapist');
    $assist_therapist = $this->input->post('assist_therapist');
    $id_service_package = $this->input->post('id_service_package');
	$service = array(	
            'item_service' => $item_service,
            'id_service_package' => $id_service_package,
            'id_detail_transaction' => $kodeunik,		
            'transaction_no' => $transaction_no,
            'work_date' => $work_date,
            'detail_item' => 2
			);
            $main = array(		
                'main_commission' => $main_commission,
                'id_detail_transaction' => $kodeunik,
                'id_beautycian' => $main_therapist,
                );
                $assist = array(	
                    'id_detail_transaction' => $kodeunik,
                    'assist_commission' => $assist_commission,
                    'id_beautycian' => $assist_therapist,
                    );

    $this->umum->input_data($service,'detail_transaction'); 
    $this->umum->input_data($main,'main_commission');
    $this->umum->input_data($assist,'assist_commission');
  
	 $notif = " Success add data";

            $this->session->set_flashdata('success', $notif);
	redirect(base_url()."app/detail_transaction/".$transaction_no.'/'.$jenis);
    }
function add_detail_service_transaction(){
    $item_service=$this->input->post('item_service');
    $date=date('md');
    $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 20);  
    $kodeunik = 'svd-'.$kode_unik.''. $date;
    $transaction_no=$this->input->post('transaction_no');
	$price = $this->input->post('price');
    $jenis = $this->input->post('jenis');
    $qty = $this->input->post('qty');
	$discount = $this->input->post('discount');
    $work_date = $this->input->post('work_date');
    $main_commission = $this->input->post('main_commission');
    $assist_commission = $this->input->post('assist_commission');
    $main_therapist = $this->input->post('main_therapist');
    $assist_therapist = $this->input->post('assist_therapist');
     $sub=$price*$qty;
	$service = array(	
            'item_service' => $item_service,
            'id_detail_transaction' => $kodeunik,
			'price' => $price,
			'qty' => $qty,
            'transaction_no' => $transaction_no,
            'discount' => $discount,
             'sub_total' => ($sub)-($sub*$discount/100),
            'work_date' => $work_date,
            'detail_item' =>1
			);
            $main = array(		
                'main_commission' => $main_commission,
                'id_detail_transaction' => $kodeunik,
                'id_beautycian' => $main_therapist,
                );
                $assist = array(	
                    'id_detail_transaction' => $kodeunik,
                    'assist_commission' => $assist_commission,
                    'id_beautycian' => $assist_therapist,
                    );

    $this->umum->input_data($service,'detail_transaction');
 
    $this->umum->input_data($main,'main_commission');
    
   
    $this->umum->input_data($assist,'assist_commission');
    $querysum = $this->db->query("Select sum(sub_total) as total from detail_transaction where transaction_no='$transaction_no'");
    foreach ($querysum->result() as $roww) {
        $total=$roww->total;
    }
  
$data = array(
'total' => $total
);
$this->db->set($data);
$this->db->where('transaction_no', $transaction_no);
$this->db->update('transaction');
	 $notif = " Success add data";

            $this->session->set_flashdata('success', $notif);
	redirect(base_url()."app/detail_transaction/".$transaction_no.'/'.$jenis);
    }
    function edit_detail_service_transaction() {
        $main_therapist = $this->input->post('main_therapisted');
    $assist_therapist = $this->input->post('assist_therapisted');
    $jenis = $this->input->post('jenis');
    $transaction_no = $this->input->post('transaction_no');
    $id_detail_transaction = $this->input->post('id_detail_transaction');
    $work_date = $this->input->post('work_date');
        $data = array(
            'work_date' => $work_date
            );
            $mt = array(
                'id_beautycian' => $main_therapist
                );
                $at = array(
                    'id_beautycian' => $assist_therapist
                    );
                    $where = array('id_detail_transaction' => $id_detail_transaction);
                    $res = $this->umum->UpdateData('detail_transaction', $data, $where);
                    $ress = $this->umum->UpdateData('main_commission', $mt, $where);
                    $resss = $this->umum->UpdateData('assist_commission', $at, $where);
                 $notif = " Success Update data";
            
                        $this->session->set_flashdata('success', $notif);
                redirect(base_url()."app/detail_transaction/".$transaction_no.'/'.$jenis);
                
    }
   
    function add_detail_item_transaction(){
        $item_service=$this->input->post('item_service');
        $transaction_no=$this->input->post('transaction_no');
        $price = $this->input->post('price');
        $jenis = $this->input->post('jenis');
        $work_date = $this->input->post('work_date');
        $qty = $this->input->post('qty');
        $id_item_list = $this->input->post('id_item_list');
        $discount = $this->input->post('discount');
        $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 20);  
        $kodeunik = 'svd-'.$kode_unik.''. $date;
        $sub=$price*$qty;
        $item = array(	
                'item_service' => $item_service,
                'id_item_list' => $id_item_list,
                'id_detail_transaction' => $kodeunik,
                'price' => $price,
                'transaction_no' => $transaction_no,
                'discount' => $discount,
                'qty' => $qty,
                'work_date' => $work_date,
                'detail_item' => 3,
                'sub_total' => ($sub)-($sub*$discount/100),
                );
              
    
        $this->umum->input_data($item,'detail_transaction');
        $querysum = $this->db->query("Select sum(sub_total) as total from detail_transaction where transaction_no='$transaction_no'");
        foreach ($querysum->result() as $roww) {
            $total=$roww->total;
        }
      
$data = array(
'total' => $total
);
$this->db->set($data);
$this->db->where('transaction_no', $transaction_no);
$this->db->update('transaction');
         $notif = " Success add data";
    
                $this->session->set_flashdata('success', $notif);
                redirect(base_url()."app/detail_transaction/".$transaction_no.'/'.$jenis);
        }
    function delete_detail_transaction($id=NULL,$transaction_no,$jenis)
    {
        $this->umum->hapus('detail_transaction','id_detail_transaction',$id);
        $this->umum->hapus('main_commission','id_detail_transaction',$id);
        $this->umum->hapus('assist_commission','id_detail_transaction',$id);
        $querysum = $this->db->query("Select sum(sub_total) as total from detail_transaction where transaction_no='$transaction_no'");
        foreach ($querysum->result() as $roww) {
            $total=$roww->total;
        }
      
    $data = array(
    'total' => $total
    );
    $this->db->set($data);
    $this->db->where('transaction_no', $transaction_no);
    $this->db->update('transaction');
         $notif = "Success Delete Data";
            $this->session->set_flashdata('delete', $notif);
            redirect(base_url()."app/detail_transaction/".$transaction_no.'/'.$jenis);
    }
    public function item_transaction()
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'Item Transaction',
            'dt_item_transaction' => $this->umum->get_item_transaction(),
            'dt_patient' => $this->umum->get_data('patient'),
        );
        $this->template->load('app/template', 'app/item_transaction', $data);
    }

        else {  echo "Anda tidak berhak menglevel halaman ini";
    }
}
function add_item_transaction()
    {
        $date=date('dm');
        $kode_unik = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 6);
$kodeunik = 'TRS-'.$kode_unik.''. $date;
        $this->db->set('id_transaction','UUID()',false);
        $this->db->set('jenis',3);
        $this->db->set('transaction_no',$kodeunik);
        $this->form_validation->set_rules('id_patient','id_patient','required');
        if($this->form_validation->run() === FALSE)
            redirect('app/item_transaction');
        else

            $this->umum->set_data("transaction");
             $notif = "Success Add Data";
            $this->session->set_flashdata('success', $notif);
            redirect('app/item_transaction');
        }
    

    function delete_item_transaction($id=NULL)
    {
        $this->umum->hapus('transaction','transaction_no',$id);
        $this->umum->hapus('payment','transaction_no',$id);
         $notif = "Success Delete Data";
            $this->session->set_flashdata('delete', $notif);
        redirect('app/item_transaction');
    }
    
 public function akun()
    {
        if($this->session->userdata('akses')<'3') {
        $data = array(
            'judul' => 'Data Akun',
            'dt_akun' => $this->umum->get_data('akun'),
        );
        $this->template->load('app/template', 'app/akun', $data);
    }
      if($this->session->userdata('akses')>='2') {
        $data = array(
            'judul' => 'Data Akun',
            'dt_akun' => $this->umum->get_akun(),
        );
        $this->template->load('app/template', 'app/akun', $data);
    }
   
    }

    function delete_akun($id=NULL)
    {
        $this->umum->hapus('akun','id_akun',$id);
         $notif = " Data berhasil dihapuskan";
            $this->session->set_flashdata('delete', $notif);
        redirect('app/akun');
    }
    
        function update_akun(){
$email = $this->input->post('email');
$id_akun = $this->input->post('id_akun');
$password = sha1($this->input->post('password'));
if($password !='da39a3ee5e6b4b0d3255bfef95601890afd80709') {
    $data_update = array(
            'email' => $email,
            'id_akun' => $id_akun,
            'password' => $password
        );
}
else {
    $data_update = array(
            'email' => $email,
            'id_akun' => $id_akun
        );
}
        $where = array('id_akun' => $id_akun);
        $res = $this->umum->UpdateData('akun', $data_update, $where);
        if($res>=1){
             $notif = "Update Data Berhasil";
            $this->session->set_flashdata('update', $notif);
            redirect('app/akun');
        }else{
            echo "<h1>GAGAL</h1>";
        }
    }
  
     function laporan_paket_masuk() { 

          $dari = $this->input->post('dari');
           $sampai = $this->input->post('sampai');
$data['dt_paket_masuk']=$this->umum->get_lap_paket_masuk($dari,$sampai);
    $this->load->view('app/laporan_paket_masuk',$data);
    }
    function laporan_paket_keluar() { 

          $dari = $this->input->post('dari');
           $sampai = $this->input->post('sampai');
$data['dt_paket_keluar']=$this->umum->get_lap_paket_keluar($dari,$sampai);
    $this->load->view('app/laporan_paket_keluar',$data);
    }
    function laporan_histori() { 

          $dari = $this->input->post('dari');
           $sampai = $this->input->post('sampai');
$data['dt_histori']=$this->umum->get_lap_histori($dari,$sampai);
    $this->load->view('app/laporan_histori',$data);
    }
     function laporan_omset() { 

          $dari = $this->input->post('dari');
           $sampai = $this->input->post('sampai');
$data['dt_omset']=$this->umum->get_omset($dari,$sampai);
    $this->load->view('app/laporan_omset',$data);
    }
}
	?>