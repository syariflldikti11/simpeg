<?php
class Login_model extends CI_Model{

    

     function auth_admin($username,$password){
		$this->db->select('*');
		$this->db->from('akun');
		$this->db->where(' username = "'.$username.'" AND password=sha1("'.$password.'") ');
		$this->db->limit(1);
		$query = $this->db->get();
		return $query;
		}

 
 
}