<?php
	//----------------- CLASS MODELS -----------------------------
class Umum extends CI_model{
	//set nama tabel yang akan kita tampilkan datanya
    var $table = 'patient';
    //set kolom order, kolom pertama saya null untuk kolom edit dan hapus
    var $column_order = array(null, 'patient_number', 'patient_name', 'patient_gender','patient_pob','patient_phone','patient_address',null);

    var $column_search = array('patient_number', 'patient_name');
    // default order 
    var $order = array('id_patient' => 'asc');

	private function _get_datatables_query()
    {
        $this->db->from($this->table);
        $i = 0;
        foreach ($this->column_search as $item) // loop kolom 
        {
            if ($this->input->post('search')['value']) // jika datatable mengirim POST untuk search
            {
                if ($i === 0) // looping pertama
                {
                    $this->db->group_start();
                    $this->db->like($item, $this->input->post('search')['value']);
                } else {
                    $this->db->or_like($item, $this->input->post('search')['value']);
                }
                if (count($this->column_search) - 1 == $i) //looping terakhir
                    $this->db->group_end();
            }
            $i++;
        }

        // jika datatable mengirim POST untuk order
        if ($this->input->post('order')) {
            $this->db->order_by($this->column_order[$this->input->post('order')['0']['column']], $this->input->post('order')['0']['dir']);
        } else if (isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables()
    {
        $this->_get_datatables_query();
        if ($this->input->post('length') != -1)
            $this->db->limit($this->input->post('length'), $this->input->post('start'));
        $query = $this->db->get();
        return $query->result();
    }

    function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }

	function grafik_penjualan()
	{
	$tgl=date('Y');
	 $sql= $this->db->query("
	 
	 select distinct
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=1)AND jenis=3 and (YEAR(transaction_date)='$tgl'))),0) AS 'Januari',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=2)AND jenis=3 and (YEAR(transaction_date)=$tgl))),0) AS 'Februari',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=3)AND jenis=3 and (YEAR(transaction_date)=$tgl))),0) AS 'Maret',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=4)AND jenis=3 and (YEAR(transaction_date)=$tgl))),0) AS 'April',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=5)AND jenis=3 and (YEAR(transaction_date)=$tgl))),0) AS 'Mei',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=6)AND jenis=3 and (YEAR(transaction_date)=$tgl))),0) AS 'Juni',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=7)AND jenis=3 and (YEAR(transaction_date)=$tgl))),0) AS 'Juli',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=8)AND jenis=3 and (YEAR(transaction_date)=$tgl))),0) AS 'Agustus',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=9)AND jenis=3 and (YEAR(transaction_date)=$tgl))),0) AS 'September',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=10)AND jenis=3 and (YEAR(transaction_date)=$tgl))),0) AS 'Oktober',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=11)AND jenis=3 and (YEAR(transaction_date)=$tgl))),0) AS 'November',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=12)AND jenis=3 and (YEAR(transaction_date)=$tgl))),0) AS 'Desember'
	from transaction GROUP BY YEAR(transaction_date) 
	 
	 ");
	 
	 return $sql;
	 
	}
	function grafik_service_package()
	{
	$tgl=date('Y');
	 $sql= $this->db->query("
	 
	 select distinct
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=1)AND jenis=2 and (YEAR(transaction_date)='$tgl'))),0) AS 'Januari',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=2)AND jenis=2 and (YEAR(transaction_date)=$tgl))),0) AS 'Februari',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=3)AND jenis=2 and (YEAR(transaction_date)=$tgl))),0) AS 'Maret',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=4)AND jenis=2 and (YEAR(transaction_date)=$tgl))),0) AS 'April',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=5)AND jenis=2 and (YEAR(transaction_date)=$tgl))),0) AS 'Mei',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=6)AND jenis=2 and (YEAR(transaction_date)=$tgl))),0) AS 'Juni',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=7)AND jenis=2 and (YEAR(transaction_date)=$tgl))),0) AS 'Juli',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=8)AND jenis=2 and (YEAR(transaction_date)=$tgl))),0) AS 'Agustus',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=9)AND jenis=2 and (YEAR(transaction_date)=$tgl))),0) AS 'September',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=10)AND jenis=2 and (YEAR(transaction_date)=$tgl))),0) AS 'Oktober',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=11)AND jenis=2 and (YEAR(transaction_date)=$tgl))),0) AS 'November',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=12)AND jenis=2 and (YEAR(transaction_date)=$tgl))),0) AS 'Desember'
	from transaction GROUP BY YEAR(transaction_date) 
	 
	 ");
	 
	 return $sql;
	 
	}
	function grafik_service()
	{
	$tgl=date('Y');
	 $sql= $this->db->query("
	 
	 select distinct
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=1)AND jenis=1 and (YEAR(transaction_date)='$tgl'))),0) AS 'Januari',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=2)AND jenis=1 and (YEAR(transaction_date)=$tgl))),0) AS 'Februari',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=3)AND jenis=1 and (YEAR(transaction_date)=$tgl))),0) AS 'Maret',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=4)AND jenis=1 and (YEAR(transaction_date)=$tgl))),0) AS 'April',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=5)AND jenis=1 and (YEAR(transaction_date)=$tgl))),0) AS 'Mei',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=6)AND jenis=1 and (YEAR(transaction_date)=$tgl))),0) AS 'Juni',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=7)AND jenis=1 and (YEAR(transaction_date)=$tgl))),0) AS 'Juli',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=8)AND jenis=1 and (YEAR(transaction_date)=$tgl))),0) AS 'Agustus',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=9)AND jenis=1 and (YEAR(transaction_date)=$tgl))),0) AS 'September',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=10)AND jenis=1 and (YEAR(transaction_date)=$tgl))),0) AS 'Oktober',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=11)AND jenis=1 and (YEAR(transaction_date)=$tgl))),0) AS 'November',
	 ifnull((SELECT sum(total) FROM (transaction)  WHERE((Month(transaction_date)=12)AND jenis=1 and (YEAR(transaction_date)=$tgl))),0) AS 'Desember'
	from transaction GROUP BY YEAR(transaction_date) 
	 
	 ");
	 
	 return $sql;
	 
	}
     function get_lap_absensi($id_pegawai,$dari,$sampai){
		$this->db->select('*');
		$this->db->from('absensi a');
		$this->db->join('pegawai b','a.id_pegawai=b.id_pegawai','');
		$this->db->where('a.tgl_absensi between "'.$dari.'" and "'.$sampai.'" and b.id_pegawai '.$id_pegawai.'');   
		$query = $this->db->get();
		return $query->result();
		}
		function get_item_name(){
		$this->db->select('*');
		$this->db->from('item_name ');	
		$this->db->order_by('item_name asc');
		$query = $this->db->get();
		return $query->result();
		}
	function get_item_list(){
		$this->db->select('*');
		$this->db->from('item_list a');	
		$this->db->join('item_name b','a.id_item_name=b.id_item_name','');
		$this->db->join('item_unit c','a.unit=c.id_item_unit','');
		$this->db->order_by('item_name asc');
		$query = $this->db->get();
		return $query->result();
		}
		function get_therapist_schedule(){
			$this->db->select('*');
			$this->db->from('detail_transaction a');	
			$this->db->join('transaction b','a.transaction_no=b.transaction_no','');
			$this->db->join('patient c','b.id_patient=c.id_patient','');
			$this->db->where('a.detail_item < 3 and status=0');   
			$this->db->order_by('a.work_date asc');
			$query = $this->db->get();
			return $query->result();
			}
			function get_commission(){
				$this->db->select('*');
				$this->db->from('detail_transaction a');	
				$this->db->join('transaction b','a.transaction_no=b.transaction_no','');
				$this->db->join('patient c','b.id_patient=c.id_patient','');
				$this->db->where('a.detail_item < 3 and status=1');   
				$this->db->order_by('a.work_date asc');
				$query = $this->db->get();
				return $query->result();
				}
			function get_medical_record($id){
				$this->db->select('*');
				$this->db->from('detail_transaction a');	
				$this->db->join('transaction b','a.transaction_no=b.transaction_no','');
				$this->db->join('patient c','b.id_patient=c.id_patient','');
				$this->db->where('a.detail_item < 3');   
				$this->db->where('c.id_patient',$id);  
				$this->db->order_by('a.work_date asc');
				$query = $this->db->get();
				return $query->result();
				}
		function get_service_transaction(){
			$this->db->select('*');
			$this->db->from('transaction a');	
			$this->db->join('patient b','a.id_patient=b.id_patient','');
			$this->db->where('a.jenis',1);   
			$this->db->order_by('no_urut desc');
			$query = $this->db->get();
			return $query->result();
			}
			function get_package_transaction(){
				$this->db->select('*');
				$this->db->from('transaction a');	
				$this->db->join('patient b','a.id_patient=b.id_patient','');
				$this->db->where('a.jenis',2);   
				$this->db->order_by('no_urut desc');
				$query = $this->db->get();
				return $query->result();
				}
			function get_detail_transaction($id){
				$this->db->select('*');
				$this->db->from('detail_transaction a');
				$this->db->where('a.transaction_no',$id);   
				$query = $this->db->get();
				return $query->result();
				}
				function get_payment($id){
					$this->db->select('*');
					$this->db->from('payment a');
					$this->db->where('a.transaction_no',$id);   
					$query = $this->db->get();
					return $query->result();
					}
			function get_item_transaction(){
				$this->db->select('*');
				$this->db->from('transaction a');	
				$this->db->join('patient b','a.id_patient=b.id_patient','');
				$this->db->where('a.jenis',3);   
				$this->db->order_by('no_urut desc');
				$query = $this->db->get();
				return $query->result();
				}
		function get_incoming_item(){
		$this->db->select('*');
		$this->db->from('incoming_item a');	
		$this->db->join('item_name b','a.id_item_name=b.id_item_name','');
		$this->db->join('item_unit c','a.unit=c.id_item_unit','');
		$this->db->order_by('tgl_input desc');
		$query = $this->db->get();
		return $query->result();
		}
		
function get_data($tabel)
	{
		$query = $this->db->get($tabel);
		return $query->result();		
	}
	function set_data($tabel)
	{
		$data=$this->input->post(null,TRUE);
		array_pop($data);
		return $this->db->insert($tabel, $data);
	}
	function input_data($data,$table){
		$this->db->insert($table,$data);
	}
	function hapus($tabel,$kolom,$id)
	{
		$this->db->delete($tabel,array($kolom => $id));
	}	
	 function UpdateData($tabelName, $data, $where){
        $res = $this->db->update($tabelName, $data, $where);
        return $res;
    }
	function update_data($tabel)
	{
		$data=$this->input->post(null,TRUE);  	
		$primary=array_slice($data,0,1);	
		array_shift($data);		
		array_pop($data);		
	    $this->db->where($primary);
	    $this->db->update($tabel, $data);	
	}
		

	
}